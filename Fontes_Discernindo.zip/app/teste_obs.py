import asyncio, re
from playwright.async_api import async_playwright
URL='http://localhost:8765/index.html'
async def click(pg,txt):
    await pg.get_by_role('button',name=re.compile(txt)).first.click(); await pg.wait_for_timeout(200)
async def marca(pg, a, b, c):
    for k,v in zip(['Que ligação','O que Deus revelou','Em sua consciência'],[a,b,c]):
        fs=pg.locator('fieldset.criterio',has_text=k)
        await fs.get_by_role('button',name=re.compile('^'+v)).first.click(); await pg.wait_for_timeout(120)
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(); ctx=await b.new_context(viewport={'width':390,'height':844})
        erros=[]; pres=await ctx.new_page(); pres.on('pageerror',lambda e:erros.append(str(e)))
        await pres.goto(URL); await click(pres,'Só experimentar'); await click(pres,'Conduzir'); await click(pres,'^Comissão de nomeações')
        await pres.fill('#igrejaIn','Igreja Teste'); await pres.fill('#presNomeIn','João'); await click(pres,'^Seguir')
        for nome in ['Diáconos','Diaconisas','Secretário','Tesoureiro','Diretor','Ministério Pessoal','Jovens']:
            await pres.get_by_role('button',name=re.compile('^'+re.escape(nome))).first.click()
        await click(pres,'^Seguir'); await pres.fill('#membrosIn','Ana\nBeto\nCaio\nDora'); await click(pres,'^Seguir')
        await click(pres,'^Beto'); await click(pres,'Criar a reunião'); await pres.wait_for_timeout(400)
        code=(await pres.locator('.codigo').inner_text()).replace(' ','')
        ms=[]
        for n in ['M1','M2','M3','M4']:
            pg=await ctx.new_page(); pg.on('pageerror',lambda e:erros.append(str(e)))
            await pg.goto(f'http://localhost:8765/index.html?r={code}#teste'); await pg.fill('#nomeIn',n); await click(pg,'^Entrar'); ms.append(pg)
        await click(pres,'Começar')
        for i in range(7): await click(pres,'^Seguir')
        await click(pres,'^Anciãos'); await click(pres,'Abrir as propostas')
        for pg in [pres]+ms:
            for n in ['Ana','Beto']: await pg.locator('.nomes .nomeBtn',has_text=n).first.click()
            await click(pg,'^Enviar')
        await click(pres,'Ver a lista'); await click(pres,'Observar com atenção|Começar as observações')
        # Ana: everyone high except one very low -> trimmed; Beto: close to Ana -> tie note (Beto serve hoje)
        ana=[('Excelente','Muito bom','Excelente'),('Excelente','Excelente','Muito bom'),('Muito bom','Muito bom','Muito bom'),('Excelente','Bom','Excelente'),('Precisa crescer muito','Bom','Bom')]
        for pg,(a,bb,c) in zip([pres]+ms,ana): await marca(pg,a,bb,c)
        await ms[0].screenshot(path='shots/b1_obs.png',full_page=True)
        await click(pres,'Próximo nome')
        beto=[('Excelente','Excelente','Excelente'),('Muito bom','Excelente','Muito bom'),('Excelente','Muito bom','Bom'),('Muito bom','Muito bom','Muito bom')]
        for pg,(a,bb,c) in zip([pres]+ms[:3],beto): await marca(pg,a,bb,c)
        await ms[3].get_by_role('button',name='Não conheço esta pessoa o bastante para marcar').click(); await ms[3].wait_for_timeout(200)
        await click(pres,'Ver o quadro da comissão'); await pres.wait_for_timeout(300)
        await ms[1].screenshot(path='shots/b2_quadro.png',full_page=True)
        print(await ms[1].locator('.quadro').inner_text())
        print('erros',erros); await b.close()
asyncio.run(main())
