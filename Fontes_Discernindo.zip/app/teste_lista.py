import asyncio, re
from playwright.async_api import async_playwright
URL='http://localhost:8765/index.html'
async def click(pg,txt):
    await pg.get_by_role('button',name=re.compile(txt)).first.click(); await pg.wait_for_timeout(200)
async def marca(pg, a, b, c):
    for k,v in zip(['Que ligação','O que Deus revelou','Em sua consciência'],[a,b,c]):
        await pg.locator('fieldset.criterio',has_text=k).get_by_role('button',name=re.compile('^'+v)).first.evaluate('e=>e.click()'); await pg.wait_for_timeout(120)
NIV=['Excelente','Muito bom','Bom','Precisa crescer um pouco','Precisa crescer muito']
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(); ctx=await b.new_context(viewport={'width':390,'height':844}); ctx.set_default_timeout(6000)
        erros=[]; pres=await ctx.new_page(); pres.on('pageerror',lambda e:erros.append(str(e)))
        await pres.goto(URL); await click(pres,'Só experimentar'); await click(pres,'Conduzir'); await click(pres,'^Comissão de nomeações')
        await pres.fill('#igrejaIn','Igreja Teste'); await pres.fill('#presNomeIn','João'); await click(pres,'^Seguir')
        for nome in ['Diáconos','Diaconisas','Secretário','Tesoureiro','Diretor','Ministério Pessoal','Jovens']:
            await pres.get_by_role('button',name=re.compile('^'+re.escape(nome))).first.click()
        await click(pres,'^Seguir'); await pres.fill('#membrosIn','Ana\nBeto\nCaio\nDora\nEva\nFabio'); await click(pres,'^Seguir')
        await click(pres,'Criar a reunião'); await pres.wait_for_timeout(400)
        code=(await pres.locator('.codigo').inner_text()).replace(' ','')
        ms=[]
        for n in ['M1','M2']:
            pg=await ctx.new_page(); pg.on('pageerror',lambda e:erros.append(str(e)))
            await pg.goto(f'http://localhost:8765/index.html?r={code}#teste'); await pg.fill('#nomeIn',n); await click(pg,'^Entrar'); ms.append(pg)
        await click(pres,'Começar')
        for i in range(7): await click(pres,'^Seguir')
        await click(pres,'^Anciãos'); await click(pres,'Mais uma'); await pres.screenshot(path='shots/d0_vagas.png',full_page=True); await click(pres,'Abrir as propostas')
        for pg in [pres]+ms:
            for n in ['Ana','Beto','Caio','Dora','Eva']: await pg.locator('.nomes .nomeBtn',has_text=n).first.click()
            await click(pg,'^Enviar')
        await click(pres,'Ver a lista'); await pres.screenshot(path='shots/c1_lista.png',full_page=True)
        await click(pres,'Começar as observações')
        # levels per name: Ana high, Beto high, Caio mid, Dora low, Eva mid-high
        lv={'Ana':0,'Beto':0,'Caio':2,'Dora':4,'Eva':1}
        for k,nome in enumerate(['Ana','Beto','Caio','Dora','Eva']):
            if k==0: await ms[0].screenshot(path='shots/c2_obs_rapida.png',full_page=True)
            for pg in [pres]+ms: await marca(pg,NIV[lv[nome]],NIV[lv[nome]],NIV[lv[nome]])
            if k<4: await click(pres,'Próximo nome')
        await click(pres,'Ver o quadro da comissão'); await pres.screenshot(path='shots/c3_quadro.png',full_page=True)
        await click(pres,'Afinar a lista pela nota'); await pres.screenshot(path='shots/c4_afinar.png',full_page=True)
        await click(pres,'^Confirmar'); await pres.screenshot(path='shots/c5_lista_afinada.png',full_page=True)
        await click(pres,'Observar com atenção'); await ms[1].screenshot(path='shots/c6_obs_atencao.png',full_page=True)
        n=await pres.locator('h1').inner_text(); print('primeiro nome rodada 2:',n)
        for k in range(3):
            for j,pg in enumerate([pres]+ms):
                try: await marca(pg,NIV[k],NIV[k],NIV[k])
                except Exception as e:
                    await pg.screenshot(path='shots/falha.png',full_page=True); print('falhou k',k,'pg',j, await pg.locator('h1').inner_text()); raise
            if k<2: await click(pres,'Próximo nome')
        await click(pres,'Ver o quadro da comissão'); await click(pres,'Ir para a oração'); await click(pres,'Abrir o discernimento secreto')
        await ms[0].screenshot(path='shots/d1_voto_multi.png',full_page=True)
        escolhas=[['Ana','Beto'],['Ana','Eva'],['Ana','Beto']]
        for pg,es in zip([pres]+ms,escolhas):
            for e in es: await pg.locator('.votos .voto',has_text=e).first.click()
            if pg==ms[1]:
                await pg.locator('.votos .voto',has_text='Beto').first.click(); await pg.wait_for_timeout(300)
                await pg.screenshot(path='shots/d2_limite.png',full_page=True)
            await click(pg,'Confirmar o que discerni')
        await click(pres,'Mostrar o resultado'); print('resultado:', await pres.locator('h1').inner_text())
        await pres.screenshot(path='shots/d3_resultado_multi.png',full_page=True)
        print('erros',erros); await b.close()
asyncio.run(main())
