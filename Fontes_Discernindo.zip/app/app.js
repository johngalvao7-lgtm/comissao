// A Comissão — uma reunião da comissão de nomeações, passo a passo, cada membro no próprio celular.
// Modo real: Firebase (Firestore + login anônimo). Modo de teste: tudo neste aparelho (abas diferentes simulam membros).

/* ======================= TEXTOS ======================= */
const ABERTURA = [
  { titulo: 'Antes de tudo, oração.',
    fala: 'Alguém ora em voz alta, pedindo que Cristo presida esta reunião.',
    cita: 'Pediu-se em oração que Cristo presidisse à reunião, e comunicasse Sua sabedoria, Sua graça e justiça.', ref: 'OE 448.1' },
  { titulo: 'Quatro combinados para hoje.',
    lista: [
      ['Jesus está no nosso meio.', '“Conservemos em mente que Jesus Se acha em nosso meio.”', 'OE 448.2'],
      ['Coração aberto e manso.', 'Nada de espírito “indiferente, endurecido, crítico, não amoroso”.', 'T7 256.2'],
      ['O que se fala aqui fica aqui.', 'Todas as consultas e conversas da comissão são confidenciais.', 'Manual da Igreja, cap. 10'],
      ['Hora de parar.', 'Combinem agora a hora de terminar. “Ofereçam repouso ao cérebro cansado.”', 'T7 256.2']
    ] }
];
const ESTUDO = [
  { titulo: 'Quem escolhe é Deus. Nós discernimos.',
    cita: 'Devemos apresentar a Deus cada caso, e, com oração fervorosa, pedir-Lhe que escolha por nós.', ref: 'T9 264.1' },
  { titulo: 'Todos pesam. Ninguém domina.',
    cita: 'Ao dar conselho para o avanço da obra, homem nenhum sozinho deve ser um poder dominante, uma voz por todos.', ref: 'T7 259.1' },
  { titulo: 'Sem pressa.',
    cita: 'É muito melhor provar o homem antes de receber um cargo do que depois.', ref: 'T5 618.1' },
  { titulo: 'Sobretudo, gente que anda com Deus.',
    cita: 'Sobretudo, escolhei os que, na simplicidade de sua alma, estejam andando na verdade, que amem e temam a Deus, e aprendam em Sua escola.', ref: 'CES 165.1' },
  { titulo: 'Nem sorte, nem gosto pessoal.',
    cita: 'Lançar sortes para os oficiais da igreja não está no plano de Deus. Chamem-se homens de responsabilidade para escolher os oficiais da igreja.', ref: 'ME2 328.6',
    nota: 'O texto completo de cada princípio está no livro, na parte “Os textos completos”.' }
];
const CRITERIOS = [
  { k: 'a', t: 'Que ligação com Deus você percebe nesta pessoa?', d: 'Ama e teme a Deus, ora, vive a verdade com simplicidade. É o que mais pesa.', ref: 'CES 165.1', peso: 70 },
  { k: 'b', t: 'O que Deus revelou para esta função, você percebe nela?', d: 'As características que Deus pede para esta função.', ref: '', peso: 15 },
  { k: 'ch', t: 'Em sua consciência, você discerne que Deus a está chamando para esta função?', d: '“O Senhor tem certos homens para ocupar determinados cargos.”', ref: 'T9 264.1', peso: 15 }
];
const NIVEIS = [[5, 'Excelente'], [4, 'Muito bom'], [3, 'Bom'], [2, 'Precisa crescer um pouco'], [1, 'Precisa crescer muito']];
const notaDe = e => e && !e.nc && e.a && e.b && e.ch ? e.a * 14 + e.b * 3 + e.ch * 3 : null; // = 70% + 15% + 15%, em pontos de 20 a 100
function notasDaRodada(fid) {
  const ra = S.M?.rodadaAval?.[fid] || 1, r = {};
  restantes(fid).forEach(id => { r[id] = consolidar(entradas('av', fid, ra).filter(e => e.c === id).map(notaDe).filter(x => x !== null)); });
  return r;
}
function consolidar(notas) {
  if (!notas.length) return null;
  const o = [...notas].sort((x, y) => x - y);
  const usadas = o.length >= 5 ? o.slice(1, -1) : o;
  return { nota: Math.round(usadas.reduce((s, x) => s + x, 0) / usadas.length), n: o.length, min: o[0], max: o[o.length - 1], aparada: o.length >= 5 };
}
const PERGUNTAS = [
  ['Anda com Deus?', 'Ama e teme a Deus, ora, vive a verdade com simplicidade.', 'CES 165.1'],
  ['Deus a chama para esta função?', '“O Senhor tem certos homens para ocupar determinados cargos.”', 'T9 264.1'],
  ['Deus lhe deu habilidade para o que a função pede?', 'Vejam as características desta função.', ''],
  ['E a experiência?', 'Já ter servido não pesa contra nem a favor. Só ajuda a desempatar.', 'T5 619']
];
const TIPOS = {
  anciao: { linhas: [['Vida limpa e boa reputação, também em casa', 'Tito 1:5-7; T5 617-618'], ['Comunhão viva com Deus, tato e bom senso', 'T5 618.2'], ['Sabe dar a cada membro uma parte no trabalho', 'SC 46.6'], ['Cuida dos fracos e dos que se afastaram', 'CES38 84.2']],
    cita: 'Devem arranjar as coisas de maneira que todos os membros da igreja tenham uma parte a desempenhar.', ref: 'SC 46.6' },
  diacono: { linhas: [['Boa reputação', 'Atos 6:3'], ['Cheio do Espírito Santo e de sabedoria', 'Atos 6:3'], ['Cuida dos fracos e dos que se afastaram', 'CES38 84.2']],
    cita: 'Escolhei, pois, irmãos, dentre vós, sete varões de boa reputação, cheios do Espírito Santo e de sabedoria.', ref: 'Atos 6:3' },
  fiel: { linhas: [['Fidelidade comprovada no que lhe é confiado', '1 Coríntios 4:2'], ['Comunhão viva com Deus', 'T5 618.2']],
    cita: 'Além disso, requer-se nos despenseiros que cada um se ache fiel.', ref: '1 Coríntios 4:2' },
  escola: { linhas: [['Anda na verdade, ama e teme a Deus, aprende em Sua escola', 'CES 165.1'], ['Guiado pelo Espírito Santo', 'TS2 564.1'], ['Tato, ânimo e capacidade de dirigir', 'Conselhos sobre a Escola Sabatina'], ['Estuda e pratica a Palavra', 'Conselhos sobre a Escola Sabatina']],
    cita: 'Sobretudo, escolhei os que, na simplicidade de sua alma, estejam andando na verdade, que amem e temam a Deus, e aprendam em Sua escola.', ref: 'CES 165.1' },
  missao: { linhas: [['Inteiramente convertido', 'T6 85-86'], ['Serve pela palavra e pelos atos', 'T6 85-86'], ['Envolve os membros na missão', 'T6 85-86']],
    cita: 'Escolham-se os mais habilitados para instruir, aqueles que sejam capazes de servir tanto pela palavra como pelos atos.', ref: 'T6 85-86' },
  jovens: { linhas: [['Intimamente ligado a Deus', 'CES 164.2'], ['Guia os jovens por caminhos seguros', 'CES38 84.2-84.3'], ['Pronto para discernir e eficiente para fazer', 'CES 164.2']],
    cita: 'Muitos são prontos em discernir e eficientes em executar, mas precisam estar intimamente ligados a Deus.', ref: 'CES 164.2' },
  dirigente: { linhas: [['Comunhão viva com Deus', 'T5 618.2'], ['Tato e bom senso', 'T5 618.2'], ['Diligente, zeloso e sem interesse próprio', 'T5 618-619']],
    cita: 'Que sejam homens e mulheres inteiramente convertidos.', ref: 'T6 85-86' }
};
TIPOS.comissao = { linhas: [['Anda com Deus: ora e vive a verdade', 'CES 165.1'], ['Bom senso e o bem da igreja no coração', 'Manual da Igreja, cap. 10'], ['Pessoa de responsabilidade', 'ME2 328.6'], ['Sabe guardar o que é confidencial', 'Manual da Igreja, cap. 10']],
  cita: 'Chamem-se homens de responsabilidade para escolher os oficiais da igreja.', ref: 'ME2 328.6' };
const FUNCOES_ORGANIZADORA = [['Membros da comissão de nomeações', 'comissao', true], ['Secretário(a) da comissão de nomeações', 'comissao', true], ['Presidente da comissão (só se o pastor não for presidir)', 'comissao', false]];
const ehOrganizadora = () => (S.M?.tipo || S.ui.wiz?.tipo) === 'organizadora';
const FUNCOES_PADRAO = [
  ['Anciãos', 'anciao'], ['Diáconos', 'diacono'], ['Diaconisas', 'diacono'], ['Secretário(a)', 'fiel'], ['Tesoureiro(a)', 'fiel'],
  ['Diretor(a) da Escola Sabatina', 'escola'], ['Ministério Pessoal', 'missao'], ['Jovens', 'jovens'], ['Desbravadores', 'jovens'],
  ['Ministério da Criança', 'jovens'], ['Ministério da Mulher', 'dirigente'], ['Música', 'dirigente'], ['Comunicação', 'dirigente']
];
const ALTERNANCIA = {
  um: 'Fica quem anda mais perto de Deus, com chamado e habilidade para a função, mesmo que já sirva nela. A mesma pessoa pode ser reeleita “caso o seu serviço se tenha provado uma bênção para a igreja”.', refUm: 'T5 619',
  dois: 'Se duas pessoas estão no mesmo nível em tudo, e a única diferença é que uma já serviu, vale dar a vez à outra: mentes diversas trazem novas ideias.', refDois: 'Conselhos sobre a Escola Sabatina'
};

/* ======================= UTILIDADES ======================= */
const $app = document.getElementById('app');
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const rand = (n = 6, abc = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789') => Array.from(crypto.getRandomValues(new Uint32Array(n)), x => abc[x % abc.length]).join('');
const norm = s => s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
const porNome = (a, b) => a.localeCompare(b, 'pt-BR');
const plural = (n, um, varios) => `${n} ${n === 1 ? um : varios}`;
const b64e = s => btoa(unescape(encodeURIComponent(s))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const b64d = s => decodeURIComponent(escape(atob(s.replace(/-/g, '+').replace(/_/g, '/'))));

const S = { backend: null, uid: null, code: null, M: null, E: [], tela: 'inicio', ui: {}, unsub: [], ultimaChavePasso: '' };
const modo = () => localStorage.getItem('modo'); // 'fb' | 'demo' | null
const guarda = () => (modo() === 'demo' ? sessionStorage : localStorage);

/* ======================= BANCO DE DADOS ======================= */
async function backendFirebase(cfg) {
  const V = '10.12.2', base = `https://www.gstatic.com/firebasejs/${V}/`;
  const [{ initializeApp }, A, F] = await Promise.all([
    import(base + 'firebase-app.js'), import(base + 'firebase-auth.js'), import(base + 'firebase-firestore.js')]);
  const app = initializeApp(cfg);
  const auth = A.getAuth(app);
  const cred = await A.signInAnonymously(auth);
  const db = F.initializeFirestore(app, { experimentalForceLongPolling: true });
  const mref = c => F.doc(db, 'reunioes', c);
  const eref = (c, id) => F.doc(db, 'reunioes', c, 'entradas', id);
  return {
    uid: cred.user.uid,
    getMeeting: async c => { const s = await F.getDoc(mref(c)); return s.exists() ? s.data() : null; },
    pollMeeting: async c => { const s = await F.getDocFromServer(mref(c)); return s.exists() ? s.data() : null; },
    fetchEntries: async c => { const q = await F.getDocsFromServer(F.collection(db, 'reunioes', c, 'entradas')); return q.docs.map(d => ({ id: d.id, ...d.data() })); },
    watchMeeting: (c, cb) => F.onSnapshot(mref(c), s => cb(s.exists() ? s.data() : null), e => falha(e)),
    watchEntries: (c, cb) => F.onSnapshot(F.collection(db, 'reunioes', c, 'entradas'), q => cb(q.docs.map(d => ({ id: d.id, ...d.data() }))), e => falha(e)),
    setMeeting: (c, data) => F.setDoc(mref(c), data),
    setEntry: (c, id, data) => F.setDoc(eref(c, id), data),
    addEntry: (c, data) => F.addDoc(F.collection(db, 'reunioes', c, 'entradas'), data),
    async deleteMeeting(c) {
      const q = await F.getDocs(F.collection(db, 'reunioes', c, 'entradas'));
      for (const d of q.docs) await F.deleteDoc(d.ref);
      await F.deleteDoc(mref(c));
    }
  };
}
function backendTeste() {
  let uid = sessionStorage.getItem('uidTeste');
  if (!uid) { uid = 'u' + rand(10); sessionStorage.setItem('uidTeste', uid); }
  const canal = new BroadcastChannel('comissao-teste');
  const ouvintes = [];
  const ler = c => JSON.parse(localStorage.getItem('teste:' + c) || '{"m":null,"e":{}}');
  const avisar = c => ouvintes.filter(o => o.c === c).forEach(o => o.f(ler(c)));
  const gravar = (c, st) => { localStorage.setItem('teste:' + c, JSON.stringify(st)); canal.postMessage(c); setTimeout(() => avisar(c)); };
  canal.onmessage = ev => avisar(ev.data);
  const ouvir = (c, f) => { const o = { c, f }; ouvintes.push(o); setTimeout(() => f(ler(c))); return () => ouvintes.splice(ouvintes.indexOf(o), 1); };
  return {
    uid,
    getMeeting: async c => ler(c).m,
    pollMeeting: async c => ler(c).m,
    fetchEntries: async c => Object.entries(ler(c).e).map(([id, d]) => ({ id, ...d })),
    watchMeeting: (c, cb) => ouvir(c, st => cb(st.m)),
    watchEntries: (c, cb) => ouvir(c, st => cb(Object.entries(st.e).map(([id, d]) => ({ id, ...d })))),
    setMeeting: async (c, data) => { const st = ler(c); st.m = JSON.parse(JSON.stringify(data)); gravar(c, st); },
    setEntry: async (c, id, data) => { const st = ler(c); st.e[id] = data; gravar(c, st); },
    addEntry: async (c, data) => { const st = ler(c); st.e['a' + rand(12)] = data; gravar(c, st); },
    deleteMeeting: async c => { localStorage.removeItem('teste:' + c); canal.postMessage(c); setTimeout(() => avisar(c)); }
  };
}
function falha(e) {
  console.error(e);
  S.ui.erro = 'A conexão com o banco de dados falhou. Confira a internet e toque em Tentar de novo.';
  render();
}

/* ======================= LEITURAS DO ESTADO ======================= */
const M = () => S.M;
const souPresidente = () => S.M && S.M.presidente === S.uid;
const membro = id => (S.M?.membros || []).find(m => m.id === id);
const nomeDe = id => membro(id)?.nome || '—';
const funcao = id => (S.M?.funcoes || []).find(f => f.id === id);
const presentes = () => S.E.filter(e => e.t === 'p').sort((a, b) => (a.at || 0) - (b.at || 0));
const entradas = (t, f, r) => S.E.filter(e => e.t === t && (f === undefined || e.f === f) && (r === undefined || e.r === r));
const minhaEntrada = (t, f, r) => entradas(t, f, r).find(e => e.uid === S.uid);
const servemHoje = (fid) => funcao(fid)?.servem || [];
const escolhidos = fid => S.M?.resultados?.[fid]?.escolhidos || [];
const discernidoPara = (mid, exceto) => (S.M?.funcoes || []).filter(f => f.id !== exceto && escolhidos(f.id).some(e => e.id === mid)).map(f => f.nome);
const vagasDe = fid => funcao(fid)?.vagas || 1;
const vagasRestantes = fid => Math.max(0, vagasDe(fid) - escolhidos(fid).filter(e => e.anuencia !== 'nao').length);
const listaPequena = fid => Math.max(3, (vagasRestantes(fid) || 1) + 1);
const restantes = fid => (S.M?.lista?.[fid] || []).filter(id => !escolhidos(fid).some(e => e.id === id));

function comPrazo(promessa, ms = 12000) {
  return Promise.race([promessa, new Promise((_, rej) => setTimeout(() => rej(new Error('prazo')), ms))]);
}
async function enviar(promessa) {
  try { await comPrazo(promessa); S.ui.sync = Date.now(); if (S.ui.erro) { S.ui.erro = ''; render(); } }
  catch (e) {
    console.error(e);
    S.ui.erro = e.message === 'prazo' ? 'O que você fez ainda não chegou ao servidor. Confira a internet; se continuar, toque em Atualizar.'
      : 'O servidor recusou a mudança (' + (e.code || e.message) + '). Confira se as regras do Firestore foram publicadas.';
    render(); throw e;
  }
}
async function gravarReuniao(mudar) {
  const novo = JSON.parse(JSON.stringify(S.M));
  mudar(novo);
  S.M = novo; render();
  await enviar(S.backend.setMeeting(S.code, novo));
}
const irPara = passo => gravarReuniao(m => { m.passo = passo; });

/* ======================= INÍCIO E CONEXÃO ======================= */
async function iniciar() {
  const p = new URLSearchParams(location.search);
  const h = location.hash;
  if (h.startsWith('#c=')) {
    try { const cfg = JSON.parse(b64d(h.slice(3))); localStorage.setItem('cfg', JSON.stringify(cfg)); localStorage.setItem('modo', 'fb'); } catch (e) { }
  } else if (h === '#teste') { localStorage.setItem('modo', 'demo'); }
  if (h) history.replaceState(null, '', location.pathname + location.search);
  const codigoLink = (p.get('r') || '').toUpperCase();

  if (!modo()) { S.tela = 'configurar'; render(); return; }
  await conectar();
  const sessao = JSON.parse(guarda().getItem('sessao') || 'null');
  if (codigoLink && (!sessao || sessao.code !== codigoLink)) { S.ui.codigo = codigoLink; S.tela = 'nome'; render(); return; }
  if (sessao) { await entrar(sessao.code, sessao.nome, true); return; }
  S.tela = 'inicio'; render();
}
async function conectar() {
  if (S.backend) return;
  S.tela = 'carregando'; render();
  try {
    S.backend = modo() === 'demo' ? backendTeste() : await backendFirebase(JSON.parse(localStorage.getItem('cfg')));
    S.uid = S.backend.uid;
  } catch (e) {
    console.error(e);
    S.tela = 'erroConexao'; render();
    throw e;
  }
}
async function entrar(code, nome, silencioso) {
  const m = await S.backend.getMeeting(code);
  if (!m) {
    guarda().removeItem('sessao');
    S.ui.aviso = silencioso ? '' : 'Não encontrei uma reunião com esse código. Confira as letras com o presidente.';
    S.tela = silencioso ? 'inicio' : 'nome'; render(); return;
  }
  S.code = code;
  guarda().setItem('sessao', JSON.stringify({ code, nome }));
  await S.backend.setEntry(code, 'p_' + S.uid, { t: 'p', uid: S.uid, nome, at: Date.now() });
  observar();
}
async function atualizarDoServidor() {
  try {
    const [m, es] = await Promise.all([S.backend.pollMeeting(S.code), S.backend.fetchEntries(S.code)]);
    S.ui.sync = Date.now();
    if (m) { S.M = m; S.E = es; S.tela = 'reuniao'; S.ui.erro = ''; render(); }
  } catch (e) { console.error(e); S.ui.erro = 'Não consegui falar com o servidor. Confira a internet e tente de novo.'; render(); }
}
function observar() {
  S.unsub.forEach(u => u()); S.unsub = [];
  clearInterval(S.vigia);
  // rede de segurança: a cada 8 segundos confere o passo da reunião direto no servidor
  if (modo() !== 'demo') S.vigia = setInterval(async () => {
    try {
      const m = await S.backend.pollMeeting(S.code);
      S.ui.sync = Date.now();
      if (m && JSON.stringify(m) !== JSON.stringify(S.M)) { S.M = m; S.tela = 'reuniao'; render(); }
    } catch (e) { console.error(e); }
    pilula();
  }, 8000);
  S.unsub.push(S.backend.watchMeeting(S.code, m => {
    if (!m) { // reunião apagada
      S.M = null; S.E = []; guarda().removeItem('sessao'); S.tela = 'apagada'; render(); return;
    }
    S.M = m; S.tela = 'reuniao'; S.ui.sync = Date.now(); render();
  }));
  S.unsub.push(S.backend.watchEntries(S.code, es => { S.E = es; S.ui.sync = Date.now(); if (S.M) render(); }));
}

/* ======================= DESENHO DAS TELAS ======================= */
const ETAPAS = [['Abertura', ['abertura', 'estudo']], ['Função', ['funcao', 'escolherFuncao']], ['Propostas', ['propostas', 'lista', 'filtro']], ['Observações', ['observacoes', 'quadro', 'filtroResultado']], ['Oração e voto', ['oracao', 'voto', 'resultado']]];
function trilha() {
  const el = document.getElementById('trilha');
  const t = S.tela === 'reuniao' ? S.M?.passo?.t : null;
  if (!t || t === 'espera' || t === 'fim') { el.innerHTML = ''; el.hidden = true; return; }
  el.hidden = false;
  const atual = ETAPAS.findIndex(e => e[1].includes(t));
  const f = S.M.passo.f ? funcao(S.M.passo.f) : null;
  el.innerHTML = `<ol aria-label="Etapas da reunião">${ETAPAS.map((e, i) =>
    `<li class="${i < atual ? 'feito' : i === atual ? 'agora' : ''}"${i === atual ? ' aria-current="step"' : ''}><span class="gota"></span><span class="rot">${e[0]}</span></li>`).join('')}</ol>
    ${f && atual > 0 ? `<p class="funcaoAtual">${esc(f.nome)}</p>` : ''}`;
}
const cita = (t, ref) => t ? `<blockquote><p>${esc(t)}</p>${ref ? `<cite>${esc(ref)}</cite>` : ''}</blockquote>` : '';
const botao = (acao, rotulo, cls = '', extra = '') => `<button class="btn ${cls}" data-a="${acao}" ${extra}>${rotulo}</button>`;
const rodape = (html) => html ? `<div class="acoes">${html}</div>` : '';
const esperaPresidente = (txt = 'O presidente vai seguir quando todos estiverem prontos.') => souPresidente() ? '' : `<p class="espera"><span class="pulso"></span>${txt} <button class="link" data-a="atualizar">Atualizar</button></p>`;
function pilula() {
  let el = document.getElementById('pilula');
  if (!el) { el = document.createElement('div'); el.id = 'pilula'; el.setAttribute('role', 'status'); document.body.appendChild(el); }
  if (modo() === 'demo' || S.tela !== 'reuniao') { el.hidden = true; return; }
  const ok = S.ui.sync && Date.now() - S.ui.sync < 25000;
  el.hidden = false; el.className = ok ? 'ok' : 'falha';
  el.textContent = ok ? 'conectado' : 'sem conexão';
}

function render() {
  // guardar foco e cursor de campos de texto
  const ativo = document.activeElement;
  const foco = ativo && ativo.id ? { id: ativo.id, a: ativo.selectionStart, b: ativo.selectionEnd } : null;
  trilha();
  let html = '';
  try { html = S.tela === 'reuniao' ? telaReuniao() : (TELAS[S.tela] || TELAS.inicio)(); }
  catch (e) { console.error(e); html = `<section class="tela"><h1>Algo saiu do lugar.</h1><p>Recarregue a página. Nada do que foi enviado se perde.</p></section>`; }
  if (S.ui.erro) html = `<div class="erro" role="alert">${esc(S.ui.erro)} ${botao('recarregar', 'Tentar de novo', 'leve')}</div>` + html;
  const chave = S.tela + '|' + JSON.stringify(S.M?.passo || {});
  const mudouPasso = chave !== S.ultimaChavePasso;
  S.ultimaChavePasso = chave;
  $app.innerHTML = html;
  if (mudouPasso) {
    $app.firstElementChild?.classList.add('entra');
    window.scrollTo(0, 0);
    S.ui.busca = '';
    if (S.M?.passo?.t === 'voto') { const ch = S.M.passo.f + S.M.passo.r; if (S.ui.votoChave !== ch) { S.ui.votoChave = ch; S.ui.voto = null; S.ui.votos = new Set(); } }
  }
  if (foco) { const el = document.getElementById(foco.id); if (el) { el.focus(); try { el.setSelectionRange(foco.a, foco.b); } catch (e) { } } }
  if (S.ui.desenharQR) { S.ui.desenharQR(); }
  pilula();
}

const TELAS = {
  carregando: () => `<section class="tela centro"><p class="espera"><span class="pulso"></span>Conectando…</p></section>`,
  erroConexao: () => `<section class="tela"><h1>Não consegui conectar.</h1>
    <p>Confira se há internet. Se o código do Firebase foi colado errado, cole de novo.</p>
    ${rodape(botao('recarregar', 'Tentar de novo') + botao('reconfigurar', 'Colar o código de novo', 'leve'))}</section>`,
  apagada: () => `<section class="tela"><h1>Esta reunião foi encerrada.</h1><p>O presidente apagou os dados do servidor. Obrigado por servir.</p>${rodape(botao('home', 'Voltar ao início', 'leve'))}</section>`,
  configurar: () => `<section class="tela">
    <h1>Bem-vindo.</h1>
    <p class="lead">Se você é membro da comissão, entre pelo QR code ou pelo link que o presidente mostrar.</p>
    <p>Se você é quem vai conduzir, escolha abaixo.</p>
    ${rodape(botao('irColar', 'Ligar este aparelho ao banco de dados') + botao('modoTeste', 'Só experimentar, neste aparelho', 'leve'))}</section>`,
  colar: () => `<section class="tela">
    <h1>Cole aqui o código do Firebase.</h1>
    <p>É o bloco que começa com <em>const firebaseConfig</em>. Pode colar tudo, do jeito que veio.</p>
    <label class="campo"><span class="sr">Código do Firebase</span><textarea id="cfgTexto" rows="8" spellcheck="false" placeholder="const firebaseConfig = { apiKey: ..."></textarea></label>
    ${S.ui.aviso ? `<p class="aviso">${esc(S.ui.aviso)}</p>` : ''}
    ${rodape(botao('salvarCfg', 'Ligar') + botao('voltarConfig', 'Voltar', 'leve'))}</section>`,
  inicio: () => `<section class="tela">
    <h1>O que vamos fazer?</h1>
    ${modo() === 'demo' ? `<p class="selo">Modo de experimentar: abra outras abas deste aparelho para fazer o papel dos membros.</p>` : ''}
    ${rodape(botao('novaReuniao', 'Conduzir uma reunião') + botao('irEntrar', 'Entrar numa reunião', 'leve'))}
    <p class="pe"><button class="link" data-a="reconfigurar">Trocar a ligação deste aparelho</button></p></section>`,
  nome: () => `<section class="tela">
    <h1>Como você se chama?</h1>
    <p class="lead">Só o primeiro nome. Ele aparece apenas para o presidente saber quem chegou.</p>
    ${S.ui.codigo ? '' : `<label class="campo"><span>Código da reunião</span><input id="codigoIn" autocapitalize="characters" autocomplete="off" maxlength="6" value="${esc(S.ui.codigoDigitado || '')}"></label>`}
    <label class="campo"><span class="sr">Seu nome</span><input id="nomeIn" autocomplete="given-name" maxlength="30" value="${esc(S.ui.nomeDigitado || '')}" placeholder="Seu nome"></label>
    ${S.ui.aviso ? `<p class="aviso">${esc(S.ui.aviso)}</p>` : ''}
    ${rodape(botao('entrarReuniao', 'Entrar'))}</section>`,
  // assistente do presidente
  wizTipo: () => `<section class="tela">
    <p class="voz">Vamos preparar a reunião.</p>
    <h1>Que reunião é esta?</h1>
    <div class="lista">
      <button class="item" data-a="wizTipo" data-t="nomeacoes"><span>Comissão de nomeações</span><em>Discernir os oficiais da igreja</em></button>
      <button class="item" data-a="wizTipo" data-t="organizadora"><span>Comissão organizadora</span><em>Discernir quem vai formar a comissão de nomeações</em></button>
    </div>
    ${rodape(botao('home', 'Voltar', 'leve'))}</section>`,
  wizIgreja: () => `<section class="tela">
    <p class="voz">Vamos preparar a reunião. Primeiro, o básico.</p>
    <h1>Qual é a igreja?</h1>
    <label class="campo"><span class="sr">Nome da igreja</span><input id="igrejaIn" maxlength="60" value="${esc(S.ui.wiz.igreja)}" placeholder="Ex.: Igreja Central de Condeúba"></label>
    <label class="campo"><span>E o seu nome</span><input id="presNomeIn" maxlength="30" value="${esc(S.ui.wiz.nome)}" placeholder="Seu primeiro nome"></label>
    ${rodape(botao('wizIgreja', 'Seguir'))}</section>`,
  wizFuncoes: () => {
    const w = S.ui.wiz;
    return `<section class="tela">
    <p class="voz">Pergunta 1 de 3</p>
    <h1>Quais funções a comissão vai considerar?</h1>
    <p>${w.tipo === 'organizadora' ? 'Toque para tirar ou pôr.' : 'Toque para tirar ou pôr. Confira com a lista do Manual da Igreja (Notas, nº 1).'}</p>
    <div class="escolhas">${w.funcoes.map((f, i) => `<button class="chip ${f.on ? 'on' : ''}" data-a="togFuncao" data-i="${i}" aria-pressed="${f.on}">${esc(f.nome)}</button>`).join('')}</div>
    <div class="linhaAdd"><input id="novaFuncaoIn" maxlength="40" placeholder="Outra função" value="${esc(S.ui.novaFuncao || '')}">${botao('addFuncao', 'Pôr', 'leve curto')}</div>
    ${w.tipo === 'organizadora' ? '<p class="nota">O pastor é membro da comissão de nomeações e a preside. Só se ele preferir não presidir, a organizadora recomenda um presidente (Manual da Igreja, cap. 10).</p>' : '<p class="nota">Professores da Escola Sabatina não entram aqui: a comissão da Escola Sabatina os indica (Manual da Igreja, cap. 10).</p>'}
    ${rodape(botao('wizFuncoes', 'Seguir') + botao('wizVoltar', 'Voltar', 'leve'))}</section>`;
  },
  wizMembros: () => `<section class="tela">
    <p class="voz">Pergunta 2 de 3</p>
    <h1>Quem pode ser proposto?</h1>
    <p>${S.ui.wiz.tipo === 'organizadora' ? 'Cole a lista de membros em situação regular desta igreja, um nome por linha. Só eles podem compor a comissão de nomeações (Manual da Igreja, cap. 10).' : 'Cole a lista de membros aptos, um nome por linha. É a lista que você conferiu antes, em particular, com o tesoureiro e o secretário: membros regulares e fiéis no dízimo. Ela não mostra o motivo de ninguém estar fora.'}</p>
    <label class="campo"><span class="sr">Lista de membros aptos</span><textarea id="membrosIn" rows="10" placeholder="Ana Souza&#10;Bruno Lima&#10;…">${esc(S.ui.wiz.membrosTexto)}</textarea></label>
    <p class="nota" id="contaMembros">${plural(linhasValidas(S.ui.wiz.membrosTexto).length, 'nome', 'nomes')}</p>
    ${rodape(botao('wizMembros', 'Seguir') + botao('wizVoltar', 'Voltar', 'leve'))}</section>`,
  wizServem: () => {
    const w = S.ui.wiz, f = w.funcoesOn[w.iServe];
    const busca = norm(S.ui.buscaServe || '');
    const lista = w.membros.filter(m => !busca || norm(m.nome).includes(busca));
    return `<section class="tela">
    <p class="voz">Pergunta 3 de 3 · função ${w.iServe + 1} de ${w.funcoesOn.length}</p>
    <h1>${esc(f.nome)}: ${w.tipo === 'organizadora' ? 'quem serviu no último período?' : 'quem serve hoje?'}</h1>
    <p>Isso só aparece como uma etiqueta discreta ao lado do nome. Não tira ninguém da conversa.</p>
    <label class="campo"><span class="sr">Procurar nome</span><input id="buscaServe" placeholder="Procurar nome" value="${esc(S.ui.buscaServe || '')}" autocomplete="off"></label>
    <div class="nomes">${lista.map(m => `<button class="nomeBtn ${f.servem.includes(m.id) ? 'on' : ''}" data-a="togServe" data-id="${m.id}" aria-pressed="${f.servem.includes(m.id)}">${esc(m.nome)}</button>`).join('')}</div>
    ${rodape(botao('wizServem', w.iServe + 1 < w.funcoesOn.length ? 'Próxima função' : 'Criar a reunião') + botao('wizVoltar', 'Voltar', 'leve'))}</section>`;
  }
};

function linhasValidas(t) { return [...new Set((t || '').split(/\r?\n/).map(s => s.replace(/^[\s\d.\-–•*)]+/, '').trim()).filter(Boolean))]; }

/* ---------- telas da reunião ---------- */
function telaReuniao() {
  const p = S.M.passo || { t: 'espera' };
  const fn = PASSOS[p.t];
  return fn ? fn(p) : PASSOS.espera(p);
}
function linkReuniao() {
  const base = location.origin + location.pathname + '?r=' + S.code;
  if (modo() === 'demo') return base + '#teste';
  return base + '#c=' + b64e(localStorage.getItem('cfg') || '');
}
const PASSOS = {
  espera() {
    const ps = presentes();
    if (!souPresidente()) return `<section class="tela"><p class="voz">${esc(S.M.igreja)}</p><h1>Você entrou.</h1><p class="lead">Quando o presidente começar, esta tela muda sozinha.</p>${esperaPresidente('Aguardando o início…')}</section>`;
    S.ui.desenharQR = () => desenharQR(linkReuniao());
    return `<section class="tela">
      <p class="voz">${esc(S.M.igreja)}</p>
      <h1>Mostre este código para a comissão.</h1>
      <div class="qrBox"><div id="qr" aria-label="QR code da reunião"></div><p class="codigo" aria-label="Código da reunião">${S.code.split('').join(' ')}</p></div>
      <p class="centro">${botao('compartilhar', 'Mandar o link pelo WhatsApp', 'leve curto')}</p>
      <h2>${ps.length <= 1 ? 'Só você por enquanto.' : `${ps.length} pessoas aqui`}</h2>
      <p class="presentes">${ps.map(x => esc(x.nome)).join(', ')}</p>
      ${rodape(botao('comecar', 'Começar a reunião'))}</section>`;
  },
  abertura(p) {
    const c = ABERTURA[p.s || 0];
    const corpo = c.lista ? `<ul class="combinados">${c.lista.map(([t, d, r]) => `<li><strong>${esc(t)}</strong><span>${esc(d)}</span><cite>${esc(r)}</cite></li>`).join('')}</ul>`
      : `<p class="lead">${esc(c.fala)}</p>${cita(c.cita, c.ref)}`;
    return `<section class="tela"><h1>${esc(c.titulo)}</h1>${corpo}
      ${souPresidente() ? rodape(botao('seguirAbertura', 'Seguir')) : esperaPresidente()}</section>`;
  },
  estudo(p) {
    const i = p.s || 0, c = ESTUDO[i];
    return `<section class="tela"><p class="voz">Cinco frases para lembrar · ${i + 1} de ${ESTUDO.length}</p>
      <h1>${esc(c.titulo)}</h1>${cita(c.cita, c.ref)}${c.nota ? `<p class="nota">${esc(c.nota)}</p>` : ''}
      ${souPresidente() ? rodape(botao('seguirEstudo', 'Seguir') + (i > 0 ? botao('voltarEstudo', 'Voltar', 'leve') : '')) : esperaPresidente()}</section>`;
  },
  escolherFuncao() {
    const fs = S.M.funcoes;
    const status = f => { const es = escolhidos(f.id); if (es.length) return es.map(e => nomeDe(e.id) + (e.anuencia === 'nao' ? ' (não aceitou)' : '')).join(', '); return S.M.resultados?.[f.id]?.adiada ? 'fica para outro dia' : ''; };
    const feita = f => escolhidos(f.id).length > 0 && vagasRestantes(f.id) === 0;
    const horas = (Date.now() - (S.M.inicio || Date.now())) / 36e5;
    if (!souPresidente()) return `<section class="tela"><h1>Qual função agora?</h1><p class="lead">O presidente está escolhendo.</p>
      <ul class="feitas">${fs.map(f => `<li class="${feita(f) ? 'ok' : ''}"><span>${esc(f.nome)}</span><em>${esc(status(f))}</em></li>`).join('')}</ul>${esperaPresidente('Aguardando…')}</section>`;
    const pend = fs.filter(f => !feita(f));
    return `<section class="tela"><h1>Qual função agora?</h1>
      ${horas >= 2 ? `<p class="aviso suave">Já são mais de duas horas. “Ofereçam repouso ao cérebro cansado” (T7 256.2). Vocês podem continuar outro dia com o mesmo código.</p>` : ''}
      <div class="lista">${fs.map(f => `<button class="item ${feita(f) ? 'ok' : ''}" data-a="abrirFuncao" data-f="${f.id}"><span>${esc(f.nome)}</span><em>${esc(status(f))}</em></button>`).join('')}</div>
      ${rodape(pend.length ? botao('irFim', 'Encerrar por hoje', 'leve') : botao('irFim', 'Ver o relatório final'))}</section>`;
  },
  funcao(p) {
    const f = funcao(p.f), tp = TIPOS[f.tipo] || TIPOS.dirigente;
    return `<section class="tela"><p class="voz">O que Deus pede para esta função</p>
      <h1>${esc(f.nome)}</h1>
      <ul class="caract">${tp.linhas.map(([l, r]) => `<li><span>${esc(l)}</span>${r ? `<cite>${esc(r)}</cite>` : ''}</li>`).join('')}</ul>
      ${cita(tp.cita, tp.ref)}
      ${souPresidente() ? `<div class="vagas"><span>Quantas pessoas a comissão vai discernir para ${esc(f.nome)}?</span>
        <span class="passador"><button class="mini" data-a="vagas" data-d="-1" aria-label="Menos uma">−</button><b>${vagasDe(p.f)}</b><button class="mini" data-a="vagas" data-d="1" aria-label="Mais uma">+</button></span></div>`
        : `<p class="nota">A comissão vai discernir ${plural(vagasDe(p.f), 'pessoa', 'pessoas')} para esta função.</p>`}
      <p class="nota">Antes de tudo isso vem a pergunta principal: a pessoa anda com Deus? Escolham também entre as mulheres, onde a função permitir.</p>
      ${souPresidente() ? rodape(botao('abrirPropostas', 'Abrir as propostas') + botao('voltarEscolher', 'Voltar', 'leve')) : esperaPresidente()}</section>`;
  },
  propostas(p) {
    const f = funcao(p.f);
    const enviados = entradas('pr', p.f, p.r);
    const minha = minhaEntrada('pr', p.f, p.r);
    if (S.ui.selPropostaF !== p.f + p.r) { S.ui.selPropostaF = p.f + p.r; S.ui.sel = new Set(minha?.ids || []); S.ui.editando = !minha; }
    const sel = S.ui.sel;
    const contagem = `<p class="contador">${enviados.length} de ${presentes().length} já enviaram</p>`;
    if (minha && !S.ui.editando) {
      return `<section class="tela"><h1>Seu discernimento foi enviado.</h1>
        <p class="lead">${minha.ids.length ? `Você trouxe ${minha.ids.map(nomeDe).map(esc).join(', ')}.` : 'Você ainda não trouxe nenhum nome.'}</p>
        <p>Ninguém vê quem propôs quem. Os nomes vão se juntar numa lista única.</p>${contagem}
        ${rodape((souPresidente() ? botao('fecharPropostas', 'Ver a lista', '', enviados.length ? '' : 'disabled') : '') + botao('editarProposta', 'Mudar minha proposta', 'leve'))}
        ${esperaPresidente('Aguardando os outros…')}</section>`;
    }
    const busca = norm(S.ui.busca || '');
    const lista = S.M.membros.filter(m => !busca || norm(m.nome).includes(busca));
    return `<section class="tela"><p class="voz">Em silêncio, cada um no seu celular</p>
      <h1>Em oração, quem você percebe que Deus está chamando para ${esc(f.nome)}?</h1>
      <p>Pode trazer mais de um nome, ou nenhum, se ainda não discerniu. Ninguém vai saber quem trouxe quem.</p>
      ${sel.size ? `<div class="escolhidos">${[...sel].map(id => `<button class="chip on" data-a="togNome" data-id="${id}" aria-label="Tirar ${esc(nomeDe(id))}">${esc(nomeDe(id))} ✕</button>`).join('')}</div>` : ''}
      <label class="campo"><span class="sr">Procurar nome</span><input id="buscaNome" placeholder="Procurar nome" value="${esc(S.ui.busca || '')}" autocomplete="off"></label>
      <div class="nomes">${lista.map(m => `<button class="nomeBtn ${sel.has(m.id) ? 'on' : ''}" data-a="togNome" data-id="${m.id}" aria-pressed="${sel.has(m.id)}">${esc(m.nome)}${servemHoje(p.f).includes(m.id) ? '<small>serve hoje</small>' : ''}</button>`).join('') || '<p class="nota">Nenhum nome com essas letras.</p>'}</div>
      ${contagem}
      ${rodape(botao('enviarProposta', sel.size ? `Enviar ${plural(sel.size, 'nome', 'nomes')}` : 'Ainda não discerni um nome') + (souPresidente() && enviados.length ? botao('fecharPropostas', 'Ver a lista', 'leve') : ''))}</section>`;
  },
  lista(p) {
    const f = funcao(p.f), ids = restantes(p.f), ja = escolhidos(p.f);
    const grande = ids.length > listaPequena(p.f), afinada = (S.M.rodadaAval?.[p.f] || 1) > 1;
    return `<section class="tela"><p class="voz">${afinada ? 'A lista depois de afinar' : 'Todas as propostas, juntas'}</p>
      <h1>${ids.length === 0 ? (ja.length ? 'Não sobrou nome nesta lista.' : 'Ninguém foi proposto ainda.') : ids.length === 1 ? 'Um nome para conversar.' : `${ids.length} nomes para ${esc(f.nome)}.`}</h1>
      ${ja.length ? `<p class="nota">Já discernidos: ${ja.map(e => esc(nomeDe(e.id))).join(', ')}.</p>` : ''}
      <ul class="candidatos">${ids.map(id => `<li>${esc(nomeDe(id))}${tags(id, p.f)}</li>`).join('')}</ul>
      <p class="nota">${grande ? 'Todos os nomes passam pelas observações, com as três características. Com a lista grande, um ou dois minutos por nome. Depois, a lista é afinada pela nota da comissão, e os que ficam são vistos com mais atenção. A maioria só decide no voto final.' : 'Agora, observações com atenção: cada um conta o que sabe de cada pessoa, com calma.'}</p>
      ${souPresidente() ? rodape(ids.length === 0 ? botao('reabrirPropostas', 'Abrir as propostas de novo') : botao('irObservacoes', grande ? 'Começar as observações' : 'Observar com atenção'))
      : esperaPresidente()}</section>`;
  },
  filtro(p) {
    const ids = restantes(p.f);
    const minha = minhaEntrada('mk', p.f, p.r);
    const feitos = entradas('mk', p.f, p.r).length;
    const contador = `<p class="contador">${feitos} de ${presentes().length} já marcaram</p>`;
    if (S.ui.filtroChave !== p.f + p.r) { S.ui.filtroChave = p.f + p.r; S.ui.marc = new Set(minha?.ids || []); S.ui.editandoMarca = !minha; }
    if (minha && !S.ui.editandoMarca) return `<section class="tela"><h1>Suas marcas foram enviadas.</h1>
      <p class="lead">Ninguém vê o que você marcou.</p>${contador}
      ${rodape((souPresidente() ? botao('verFiltro', 'Ver o que fica', '', feitos ? '' : 'disabled') : '') + botao('editarMarca', 'Mudar minhas marcas', 'leve'))}${esperaPresidente('Aguardando os outros…')}</section>`;
    return `<section class="tela"><p class="voz">Rodada ${p.r} · em silêncio</p>
      <h1>Quais destes você discerne que devem seguir na conversa?</h1>
      <p>Marque quantos quiser. Os nomes que quase ninguém marcar saem da conversa, por agora.</p>
      <div class="nomes">${ids.map(id => `<button class="nomeBtn ${S.ui.marc.has(id) ? 'on' : ''}" data-a="togMarca" data-id="${id}" aria-pressed="${S.ui.marc.has(id)}">${esc(nomeDe(id))}${servemHoje(p.f).includes(id) ? '<small>serve hoje</small>' : ''}</button>`).join('')}</div>
      ${contador}
      ${rodape(botao('enviarMarca', 'Enviar minhas marcas') + (souPresidente() && feitos ? botao('verFiltro', 'Ver o que fica', 'leve') : ''))}</section>`;
  },
  filtroResultado(p) {
    const fica = new Set(S.M.proposta?.fica || []);
    const ids = restantes(p.f);
    if (!souPresidente()) return `<section class="tela"><h1>O presidente está conferindo a lista.</h1>${esperaPresidente('Aguardando…')}</section>`;
    const nt = S.M.proposta?.notas || {};
    return `<section class="tela"><p class="voz">Afinar a lista</p>
      <h1>${fica.size === ids.length ? 'Todos seguem.' : `Seguem ${plural(fica.size, 'nome', 'nomes')}.`}</h1>
      <p>A sugestão mantém os nomes com as maiores notas da comissão, mais ou menos a metade, sem cortar empates. Os que saem foram vistos com as mesmas três características. Toque para ajustar se a comissão sentir diferente.</p>
      <div class="nomes">${S.M.proposta.ordem.map(id => `<button class="nomeBtn ${fica.has(id) ? 'on' : 'fora'}" data-a="togFica" data-id="${id}" aria-pressed="${fica.has(id)}">${esc(nomeDe(id))}<small>${nt[id] != null ? 'nota ' + nt[id] + ' · ' : ''}${fica.has(id) ? 'segue' : 'sai por agora'}</small></button>`).join('')}</div>
      ${rodape(botao('confirmarFiltro', 'Confirmar', '', fica.size ? '' : 'disabled') + botao('voltarLista', 'Voltar', 'leve'))}</section>`;
  },
  observacoes(p) {
    const ids = restantes(p.f), i = Math.min(p.i || 0, ids.length - 1), id = ids[i];
    const ra = S.M.rodadaAval?.[p.f] || 1;
    const chaveNota = `nota:${S.code}:${p.f}:${id}`;
    const minha = entradas('av', p.f, ra).find(e => e.uid === S.uid && e.c === id) || {};
    const feitos = entradas('av', p.f, ra).filter(e => e.c === id && (e.nc || notaDe(e) !== null)).length;
    const completo = minha.nc || notaDe(minha) !== null;
    return `<section class="tela"><p class="voz">Observações · ${i + 1} de ${ids.length}</p>
      <h1>${esc(nomeDe(id))}</h1>${tags(id, p.f, true)}
      <p class="lead">${ids.length > listaPequena(p.f) ? 'Um ou dois minutos: quem souber de algum fato importante sobre essa pessoa, fala agora.' : 'Com calma. Cada um conta o que sabe dessa pessoa que os outros talvez não saibam. Fatos, com amor.'}</p>
      <p>Depois, cada um, em oração e em silêncio, marca o que percebe. Ninguém vê a marcação do outro.</p>
      <div class="criterios ${minha.nc ? 'apagado' : ''}">${CRITERIOS.map(c => `<fieldset class="criterio"><legend><strong>${esc(c.t)}</strong> <span class="peso">${c.peso}%</span></legend>
        <p class="nota">${esc(c.d)}${c.ref ? ` <cite>${esc(c.ref)}</cite>` : ''}</p>
        <div class="niveis">${NIVEIS.map(([v, r]) => `<button class="nivel ${minha[c.k] === v ? 'on' : ''}" data-a="avaliar" data-c="${id}" data-k="${c.k}" data-v="${v}" aria-pressed="${minha[c.k] === v}">${r}</button>`).join('')}</div></fieldset>`).join('')}</div>
      <p class="nota"><strong>E a experiência?</strong> Já ter servido não pesa contra nem a favor. Só ajuda a desempatar.</p>
      <p><button class="link" data-a="avaliar" data-c="${id}" data-k="nc" data-v="${minha.nc ? 0 : 1}">${minha.nc ? 'Quero marcar esta pessoa' : 'Não conheço esta pessoa o bastante para marcar'}</button></p>
      <p class="contador">${completo ? 'Sua marcação está guardada. ' : ''}${feitos} de ${presentes().length} já marcaram</p>
      <label class="campo nota-campo"><span>Sua anotação · fica só neste celular</span><textarea id="nota-${id}" data-nota="${esc(chaveNota)}" rows="3">${esc(localStorage.getItem(chaveNota) || '')}</textarea></label>
      <p class="nota">Se for preciso perguntar algo fora da comissão, quem pergunta é o presidente (Manual da Igreja, cap. 10).</p>
      ${souPresidente() ? rodape((i + 1 < ids.length ? botao('obsProx', 'Próximo nome') : botao('irQuadro', 'Ver o quadro da comissão')) + (i > 0 ? botao('obsAnt', 'Voltar', 'leve') : botao('voltarLista', 'Ver a lista', 'leve'))) : esperaPresidente()}</section>`;
  },
  quadro(p) {
    const ids = restantes(p.f), ra = S.M.rodadaAval?.[p.f] || 1;
    const linhas = ids.map(id => {
      const es = entradas('av', p.f, ra).filter(e => e.c === id);
      return { id, r: consolidar(es.map(notaDe).filter(x => x !== null)), nc: es.filter(e => e.nc).length };
    });
    const avisos = [];
    linhas.forEach(l => { if (l.r && l.r.max - l.r.min > 30) avisos.push(`As percepções sobre ${esc(nomeDe(l.id))} estão bem diferentes (de ${l.r.min} a ${l.r.max}). Antes de votar, conversem e orem mais.`); });
    const comNota = linhas.filter(l => l.r).sort((a, b) => b.r.nota - a.r.nota);
    let empate = '';
    if (ids.length <= listaPequena(p.f) && comNota.length > 1 && comNota[0].r.nota - comNota[1].r.nota <= 5) {
      const [x, y] = comNota, serve = [x, y].filter(l => servemHoje(p.f).includes(l.id));
      empate = `<div class="alternancia"><p class="voz">${esc(nomeDe(x.id))} e ${esc(nomeDe(y.id))} estão quase no mesmo nível</p>
        ${serve.length === 1 ? `<p>${esc(nomeDe(serve[0].id))} já serve nesta função. ${esc(ALTERNANCIA.dois)} <cite>${esc(ALTERNANCIA.refDois)}</cite></p>` : '<p>A diferença é pequena. Deixem a oração e o voto mostrarem.</p>'}</div>`;
    }
    return `<section class="tela"><p class="voz">Observações · o quadro da comissão</p>
      <h1>O que a comissão percebeu.</h1>
      <p class="lead">Um retrato das marcações de todos. Ajuda a ver; quem decide é o voto, depois da oração.</p>
      <ul class="quadro">${linhas.map(l => `<li><div class="qnome"><span>${esc(nomeDe(l.id))}${servemHoje(p.f).includes(l.id) ? ' <small>serve hoje</small>' : ''}</span><b>${l.r ? l.r.nota : '—'}</b></div>
        <div class="barra"><i style="width:${l.r ? l.r.nota : 0}%"></i></div>
        <p class="nota">${l.r ? `${plural(l.r.n, 'marcação', 'marcações')}${l.r.aparada ? ', sem a maior e a menor' : ''}` : 'Ninguém marcou ainda'}${l.nc ? ` · ${l.nc} sem conhecer o bastante` : ''}</p></li>`).join('')}</ul>
      ${avisos.map(a => `<p class="aviso">${a}</p>`).join('')}${empate}
      <p class="nota">Nota de 20 a 100: anda com Deus vale 70%; o que a função pede, 15%; o chamado que vocês sentem, 15%.</p>
      ${souPresidente() ? rodape(ids.length > listaPequena(p.f)
        ? botao('verFiltro', 'Afinar a lista pela nota') + botao('voltarObs', 'Conversar mais', 'leve') + botao('marcarDeNovo', 'Marcar de novo', 'leve')
        : botao('irOracao', 'Ir para a oração') + (ids.length > 1 ? botao('verFiltro', 'Afinar mais', 'leve') : '') + botao('voltarObs', 'Conversar mais', 'leve') + botao('marcarDeNovo', 'Marcar de novo', 'leve')) : esperaPresidente()}</section>`;
  },
  oracao(p) {
    const ids = restantes(p.f);
    const alguemServe = ids.some(id => servemHoje(p.f).includes(id));
    return `<section class="tela calma"><h1>Agora, entreguem a decisão a Deus.</h1>
      <p class="lead">Um momento de silêncio. Depois, alguém ora pedindo que Deus mostre a Sua escolha.</p>
      ${cita('Tu, Senhor, conhecedor dos corações de todos, mostra qual destes tens escolhido.', 'Atos 1:24')}
      ${alguemServe ? `<div class="alternancia"><p class="voz">Uma lembrança, porque alguém aqui já serve nesta função</p>
        <p>${esc(ALTERNANCIA.um)} <cite>${esc(ALTERNANCIA.refUm)}</cite></p><p>${esc(ALTERNANCIA.dois)} <cite>${esc(ALTERNANCIA.refDois)}</cite></p></div>` : ''}
      ${souPresidente() ? rodape(botao('abrirVoto', 'Abrir o discernimento secreto') + botao('voltarObs', 'Conversar mais', 'leve')) : esperaPresidente()}</section>`;
  },
  voto(p) {
    const ids = restantes(p.f), f = funcao(p.f);
    const feito = minhaEntrada('vd', p.f, p.r);
    const n = entradas('vd', p.f, p.r).length, total = presentes().length;
    const contador = `<p class="contador">${n} de ${total} já registraram</p>`;
    const acoesPres = souPresidente() ? (n >= total ? botao('apurar', 'Mostrar o resultado') : (n ? botao('apurar', 'Encerrar assim mesmo', 'leve') : '')) : '';
    if (feito) return `<section class="tela"><h1>O que você discerniu foi registrado.</h1><p class="lead">É secreto: nem o presidente sabe o que você registrou. Continue em oração pelos outros.</p>${contador}
      ${souPresidente() ? rodape(acoesPres) : esperaPresidente('Aguardando os outros…')}</section>`;
    const k = Math.min(Math.max(1, vagasRestantes(p.f)), ids.length);
    const multi = k > 1 && ids.length > 1;
    const sel = S.ui.votos instanceof Set ? S.ui.votos : (S.ui.votos = new Set());
    const marcado = v => multi ? sel.has(v) : S.ui.voto === v;
    const opcoes = ids.length === 1
      ? [[ids[0], `Sim, discirno que é ${nomeDe(ids[0])}`], ['nao', 'Ainda não discirno']]
      : [...ids.map(id => [id, nomeDe(id)]), ['branco', 'Ainda não discerni']];
    const pronto = multi ? sel.size > 0 : !!S.ui.voto;
    return `<section class="tela"><p class="voz">Voto secreto, em oração${p.r > 1 ? ` · ${p.r}ª vez` : ''}</p>
      <h1>${ids.length === 1 ? `Em sua consciência, você discerne que ${esc(nomeDe(ids[0]))} é a escolha de Deus para ${esc(f.nome)}?` : `Em sua consciência, quem você discerne ser a escolha de Deus para ${esc(f.nome)}?`}</h1>
      ${multi ? `<p class="lead">Você pode tocar em até ${k} nomes.</p>` : ''}
      <div class="votos">${opcoes.map(([v, r]) => `<button class="voto ${marcado(v) ? 'on' : ''}" data-a="marcarVoto" data-v="${v}" data-k="${multi ? k : 1}" aria-pressed="${marcado(v)}">${esc(r)}</button>`).join('')}</div>
      ${multi ? `<p class="contador">${sel.has('branco') ? 'Ainda não discerni' : `${sel.size} de até ${k} escolhidos`}</p>` : ''}
      ${contador}
      ${rodape(botao('votar', 'Confirmar o que discerni', '', pronto ? '' : 'disabled') + acoesPres)}</section>`;
  },
  resultado(p) {
    const r = S.M.resultados[p.f]?.ultima || {}, f = funcao(p.f);
    const cont = Object.entries(r.contagem || {}).sort((a, b) => b[1] - a[1]);
    const rot = v => v === 'branco' ? 'Ainda não discerniram' : v === 'nao' ? 'Ainda não discernem' : nomeDe(v);
    const quadro = `<ul class="apuracao">${cont.map(([v, n]) => `<li><span>${esc(rot(v))}</span><b>${n}</b></li>`).join('')}</ul><p class="nota">${plural(r.total || 0, 'voto', 'votos')}. Para ser discernido, um nome precisa de mais da metade deles.</p>`;
    const eleitos = r.eleitos || (r.escolhido ? [r.escolhido] : []);
    if (eleitos.length) {
      const ps = presentes(), faltam = vagasRestantes(p.f);
      const outros = escolhidos(p.f).filter(x => !eleitos.includes(x.id));
      const nomes = eleitos.map(nomeDe).map(esc);
      return `<section class="tela"><p class="voz">${esc(f.nome)}</p><h1>A comissão discerniu: ${nomes.length > 1 ? nomes.slice(0, -1).join(', ') + ' e ' + nomes.slice(-1) : nomes[0]}.</h1>${quadro}
        ${outros.length ? `<p class="nota">Já discernidos antes para ${esc(f.nome)}: ${outros.map(x => esc(nomeDe(x.id))).join(', ')}.</p>` : ''}
        ${r.empate ? '<p class="aviso">Houve empate na última vaga. Ela fica para uma nova oração e um novo discernimento.</p>' : ''}
        ${ehOrganizadora() ? equilibrio() : ''}
        ${souPresidente() ? `<p>${ehOrganizadora() ? 'Antes de a igreja votar, cada pessoa precisa saber e concordar.' : 'Antes da primeira leitura na igreja, cada pessoa precisa saber e concordar (Manual da Igreja, cap. 10).'}</p>
          ${eleitos.map(id => { const e = escolhidos(p.f).find(x => x.id === id) || {}; return `<h2>Quem vai conversar com ${esc(nomeDe(id))}?</h2>
          <div class="escolhas">${ps.map(x => `<button class="chip ${e.quemConversa === x.nome ? 'on' : ''}" data-a="quemConversa" data-id="${id}" data-n="${esc(x.nome)}" aria-pressed="${e.quemConversa === x.nome}">${esc(x.nome)}</button>`).join('')}</div>`; }).join('')}
          ${rodape(faltam > 0 ? botao('maisUm', `Discernir ${faltam === 1 ? 'a vaga que falta' : 'as ' + faltam + ' vagas que faltam'}`) + botao('proximaFuncao', 'Próxima função', 'leve')
            : botao('proximaFuncao', 'Próxima função') + botao('maisUm', `Discernir mais uma pessoa para ${esc(f.nome)}`, 'leve'))}` : esperaPresidente()}</section>`;
    }
    return `<section class="tela"><p class="voz">${esc(f.nome)}</p><h1>Ainda não há maioria.</h1>
      <p class="lead">Isso não é fracasso. É sinal para orar e conversar mais, sem pressa.</p>${quadro}
      ${souPresidente() ? rodape(botao('votarDeNovo', 'Orar e discernir de novo') + botao('voltarObs', 'Conversar mais', 'leve') + botao('adiar', 'Deixar para outro dia', 'leve')) : esperaPresidente()}</section>`;
  },
  fim() {
    const fs = S.M.funcoes;
    const rel = relatorioTexto();
    if (!souPresidente()) return `<section class="tela"><h1>Obrigado por servir.</h1><p class="lead">O presidente está fechando a reunião. Lembre: o que se falou aqui fica aqui.</p>
      <p>Pode fechar esta página. Suas anotações estão só neste celular. ${botao('apagarNotas', 'Apagar minhas anotações', 'link')}</p></section>`;
    return `<section class="tela"><p class="voz">${esc(S.M.igreja)}</p><h1>O que a comissão discerniu.</h1>
      <ul class="relatorio">${fs.map(f => { const es = escolhidos(f.id); return `<li><span class="fn">${esc(f.nome)}</span>${es.length ? es.map(e => `<span class="nm">${esc(nomeDe(e.id))}</span>
        <span class="an">${e.quemConversa ? `Conversa: ${esc(e.quemConversa)}` : 'Falta definir quem conversa'}</span>
        <span class="estado">${['pendente', 'sim', 'nao'].map(st => `<button class="mini ${(e.anuencia || 'pendente') === st ? 'on' : ''}" data-a="anuencia" data-f="${f.id}" data-id="${e.id}" data-s="${st}" aria-pressed="${(e.anuencia || 'pendente') === st}">${{ pendente: 'Aguardando resposta', sim: 'Aceitou', nao: 'Não aceitou' }[st]}</button>`).join('')}</span>`).join('') : `<span class="nm vazio">${S.M.resultados?.[f.id]?.adiada ? 'fica para outro dia' : 'ainda não considerada'}</span>`}</li>`; }).join('')}</ul>
      <p class="nota">Se alguém não aceitar, a função volta para a comissão. Use o mesmo código em outro dia.</p>
      ${rodape(botao('copiarRelatorio', S.ui.copiado ? 'Copiado' : 'Copiar o relatório') + botao('voltarEscolher', 'Voltar às funções', 'leve'))}
      <details class="perigo"><summary>Apagar a reunião do servidor</summary>
        <p>Faça isso depois que todos aceitarem. O relatório fica guardado só neste aparelho. Isso não pode ser desfeito.</p>
        ${botao('apagarReuniao', 'Apagar agora', 'perigoBtn')}</details>
      <textarea id="relTexto" class="sr" readonly>${esc(rel)}</textarea></section>`;
  }
};
function tags(id, fid, grande) {
  const t = [];
  if (servemHoje(fid).includes(id)) t.push('serve nesta função hoje');
  discernidoPara(id, fid).forEach(n => t.push('já discernido(a) para ' + n));
  if (!t.length) return '';
  return `<span class="tags ${grande ? 'grandes' : ''}">${t.map(x => `<small>${esc(x)}</small>`).join('')}</span>`;
}
function equilibrio() {
  const todos = (S.M.funcoes || []).flatMap(f => escolhidos(f.id).map(e => nomeDe(e.id)));
  return `<div class="alternancia"><p class="voz">Equilíbrio da comissão · ${plural(todos.length, 'nome', 'nomes')} até agora</p>
    <p>${todos.map(esc).join(', ')}</p>
    <p>Confiram juntos: idades diferentes, homens e mulheres, no máximo duas pessoas da mesma família. <cite>Manual da Igreja, cap. 10</cite></p></div>`;
}
function relatorioTexto() {
  const org = ehOrganizadora();
  const linhas = [`${S.M.igreja} — ${org ? 'recomendação da comissão organizadora para a comissão de nomeações' : 'relatório da comissão de nomeações'}`, ''];
  for (const f of S.M.funcoes) {
    for (const e of escolhidos(f.id)) linhas.push(`${f.nome}: ${nomeDe(e.id)}${e.anuencia === 'sim' ? '' : e.anuencia === 'nao' ? ' (não aceitou — volta à comissão)' : ' (aguardando anuência)'}`);
  }
  linhas.push('', org ? 'A igreja vota estes nomes, e também o quórum da comissão. O pastor é membro e presidente da comissão de nomeações (Manual da Igreja, cap. 10).' : 'Primeira leitura: não se vota. A igreja tem uma semana para trazer observações à comissão, pessoalmente.');
  return linhas.join('\n');
}

/* ======================= QR ======================= */
function desenharQR(texto) {
  const alvo = document.getElementById('qr');
  if (!alvo || alvo.dataset.feito === texto) return;
  const q = qrcode(0, 'M'); q.addData(texto); q.make();
  alvo.innerHTML = q.createSvgTag({ cellSize: 4, margin: 2, scalable: true });
  alvo.dataset.feito = texto;
}

/* ======================= AÇÕES ======================= */
const ACOES = {
  recarregar: () => location.reload(),
  atualizar: () => atualizarDoServidor(),
  home: () => { S.tela = 'inicio'; render(); },
  irColar: () => { S.ui.aviso = ''; S.tela = 'colar'; render(); },
  voltarConfig: () => { S.tela = 'configurar'; render(); },
  reconfigurar: () => { localStorage.removeItem('modo'); localStorage.removeItem('cfg'); localStorage.removeItem('sessao'); sessionStorage.removeItem('sessao'); location.href = location.pathname; },
  modoTeste: async () => { localStorage.setItem('modo', 'demo'); await conectar(); S.tela = 'inicio'; render(); },
  salvarCfg: async () => {
    const t = document.getElementById('cfgTexto').value;
    const cfg = {};
    for (const m of t.matchAll(/(\w+)\s*:\s*["'`]([^"'`]+)["'`]/g)) cfg[m[1]] = m[2];
    if (!cfg.apiKey || !cfg.projectId) { S.ui.aviso = 'Não encontrei o apiKey e o projectId no que foi colado. Copie o bloco inteiro de novo.'; render(); return; }
    localStorage.setItem('cfg', JSON.stringify(cfg)); localStorage.setItem('modo', 'fb');
    try { await conectar(); S.tela = 'inicio'; render(); } catch (e) { }
  },
  irEntrar: () => { S.ui.codigo = ''; S.ui.aviso = ''; S.tela = 'nome'; render(); },
  entrarReuniao: async () => {
    const nome = document.getElementById('nomeIn').value.trim();
    const code = (S.ui.codigo || document.getElementById('codigoIn')?.value || '').trim().toUpperCase();
    if (!nome) { S.ui.aviso = 'Escreva seu nome para entrar.'; render(); return; }
    if (code.length !== 6) { S.ui.aviso = 'O código tem 6 letras e números.'; render(); return; }
    S.ui.aviso = '';
    await entrar(code, nome);
  },
  novaReuniao: () => { S.ui.wiz = { igreja: localStorage.getItem('ultimaIgreja') || '', nome: localStorage.getItem('ultimoNome') || '', membrosTexto: localStorage.getItem('ultimaLista') || '', iServe: 0 }; S.tela = 'wizTipo'; render(); },
  wizTipo: el => {
    const w = S.ui.wiz; w.tipo = el.dataset.t;
    w.funcoes = w.tipo === 'organizadora' ? FUNCOES_ORGANIZADORA.map(([nome, tipo, on]) => ({ nome, tipo, on }))
      : FUNCOES_PADRAO.map(([nome, tipo], i) => ({ nome, tipo, on: i < 8 }));
    S.tela = 'wizIgreja'; render();
  },
  wizVoltar: () => {
    const ordem = ['wizTipo', 'wizIgreja', 'wizFuncoes', 'wizMembros', 'wizServem'];
    if (S.tela === 'wizServem' && S.ui.wiz.iServe > 0) { S.ui.wiz.iServe--; } else { S.tela = ordem[Math.max(0, ordem.indexOf(S.tela) - 1)]; }
    render();
  },
  wizIgreja: () => {
    const w = S.ui.wiz; w.igreja = document.getElementById('igrejaIn').value.trim(); w.nome = document.getElementById('presNomeIn').value.trim();
    if (!w.igreja || !w.nome) return toast('Preencha a igreja e o seu nome.');
    S.tela = 'wizFuncoes'; render();
  },
  togFuncao: el => { const f = S.ui.wiz.funcoes[+el.dataset.i]; f.on = !f.on; render(); },
  addFuncao: () => {
    const v = (document.getElementById('novaFuncaoIn').value || '').trim();
    if (v) { S.ui.wiz.funcoes.push({ nome: v, tipo: 'dirigente', on: true }); S.ui.novaFuncao = ''; render(); }
  },
  wizFuncoes: () => {
    const on = S.ui.wiz.funcoes.filter(f => f.on);
    if (!on.length) return toast('Escolha pelo menos uma função.');
    S.tela = 'wizMembros'; render();
  },
  wizMembros: () => {
    const w = S.ui.wiz;
    const nomes = linhasValidas(document.getElementById('membrosIn').value).sort(porNome);
    if (nomes.length < 2) return toast('Cole pelo menos dois nomes, um por linha.');
    w.membrosTexto = document.getElementById('membrosIn').value;
    localStorage.setItem('ultimaLista', w.membrosTexto); localStorage.setItem('ultimaIgreja', w.igreja); localStorage.setItem('ultimoNome', w.nome);
    const antigos = new Map((w.membros || []).map(m => [m.nome, m.id]));
    w.membros = nomes.map((nome, i) => ({ id: antigos.get(nome) || 'm' + rand(6, 'abcdefghijkmnpqrstuvwxyz23456789'), nome }));
    const antigasF = new Map((w.funcoesOn || []).map(f => [f.nome, f.servem]));
    const ids = new Set(w.membros.map(m => m.id));
    w.funcoesOn = w.funcoes.filter(f => f.on).map((f, i) => ({ id: 'f' + (i + 1), nome: f.nome, tipo: f.tipo, servem: (antigasF.get(f.nome) || []).filter(x => ids.has(x)) }));
    w.iServe = 0; S.ui.buscaServe = '';
    S.tela = 'wizServem'; render();
  },
  togServe: el => { const f = S.ui.wiz.funcoesOn[S.ui.wiz.iServe]; const id = el.dataset.id; f.servem = f.servem.includes(id) ? f.servem.filter(x => x !== id) : [...f.servem, id]; render(); },
  wizServem: async () => {
    const w = S.ui.wiz; S.ui.buscaServe = '';
    if (w.iServe + 1 < w.funcoesOn.length) { w.iServe++; render(); return; }
    const code = rand(6);
    const m = { presidente: S.uid, tipo: w.tipo || 'nomeacoes', igreja: w.igreja, criada: Date.now(), inicio: null, funcoes: w.funcoesOn, membros: w.membros, passo: { t: 'espera' }, lista: {}, rodadaFiltro: {}, rodadaVoto: {}, resultados: {} };
    await S.backend.setMeeting(code, m);
    await entrar(code, w.nome);
  },
  compartilhar: async () => {
    const link = linkReuniao(), texto = `Reunião da comissão de nomeações — ${S.M.igreja}. Entre por aqui: ${link}`;
    if (navigator.share) { try { await navigator.share({ text: texto }); return; } catch (e) { } }
    window.open('https://wa.me/?text=' + encodeURIComponent(texto), '_blank');
  },
  comecar: () => gravarReuniao(m => { m.inicio = Date.now(); m.passo = { t: 'abertura', s: 0 }; }),
  seguirAbertura: () => { const s = S.M.passo.s || 0; irPara(s + 1 < ABERTURA.length ? { t: 'abertura', s: s + 1 } : { t: 'estudo', s: 0 }); },
  seguirEstudo: () => { const s = S.M.passo.s || 0; irPara(s + 1 < ESTUDO.length ? { t: 'estudo', s: s + 1 } : { t: 'escolherFuncao' }); },
  voltarEstudo: () => irPara({ t: 'estudo', s: Math.max(0, (S.M.passo.s || 0) - 1) }),
  abrirFuncao: el => irPara({ t: 'funcao', f: el.dataset.f }),
  voltarEscolher: () => irPara({ t: 'escolherFuncao' }),
  abrirPropostas: () => { const f = S.M.passo.f; gravarReuniao(m => { m.rodadaProp = m.rodadaProp || {}; const r = (m.rodadaProp[f] || 0) + 1; m.rodadaProp[f] = r; m.passo = { t: 'propostas', f, r }; }); },
  reabrirPropostas: () => ACOES.abrirPropostas(),
  togNome: el => { const id = el.dataset.id; S.ui.sel.has(id) ? S.ui.sel.delete(id) : S.ui.sel.add(id); render(); },
  enviarProposta: async () => {
    const { f, r } = S.M.passo; S.ui.editando = false;
    await enviar(S.backend.setEntry(S.code, `pr_${f}_${r}_${S.uid}`, { t: 'pr', uid: S.uid, f, r, ids: [...S.ui.sel] }));
    S.ui.busca = ''; render();
  },
  editarProposta: () => { S.ui.editando = true; render(); },
  fecharPropostas: () => {
    const { f, r } = S.M.passo;
    const todos = new Set(entradas('pr', f, r).flatMap(e => e.ids));
    const ids = [...todos].filter(id => membro(id) && !escolhidos(f).some(e => e.id === id)).sort((a, b) => porNome(nomeDe(a), nomeDe(b)));
    gravarReuniao(m => { m.lista[f] = ids; m.rodadaFiltro[f] = 0; m.passo = { t: 'lista', f }; });
  },
  abrirFiltro: () => { const f = S.M.passo.f; const r = (S.M.rodadaFiltro?.[f] || 0) + 1; gravarReuniao(m => { m.rodadaFiltro[f] = r; m.passo = { t: 'filtro', f, r }; }); },
  togMarca: el => { const id = el.dataset.id; S.ui.marc.has(id) ? S.ui.marc.delete(id) : S.ui.marc.add(id); render(); },
  enviarMarca: async () => {
    const { f, r } = S.M.passo; S.ui.editandoMarca = false;
    await S.backend.setEntry(S.code, `mk_${f}_${r}_${S.uid}`, { t: 'mk', uid: S.uid, f, r, ids: [...S.ui.marc] });
    render();
  },
  editarMarca: () => { S.ui.editandoMarca = true; render(); },
  verFiltro: () => {
    const { f, r } = S.M.passo;
    const notas = notasDaRodada(f);
    const proposta = sugerirCorte(restantes(f), notas, vagasRestantes(f) || 1);
    gravarReuniao(m => { m.proposta = proposta; m.passo = { t: 'filtroResultado', f, r: m.rodadaAval?.[f] || 1 }; });
  },
  togFica: el => gravarReuniao(m => { const id = el.dataset.id; const s = new Set(m.proposta.fica); s.has(id) ? s.delete(id) : s.add(id); m.proposta.fica = m.proposta.ordem.filter(x => s.has(x)); }),
  confirmarFiltro: () => {
    const f = S.M.passo.f;
    gravarReuniao(m => { const sai = m.proposta.ordem.filter(id => !m.proposta.fica.includes(id)); m.lista[f] = m.lista[f].filter(id => !sai.includes(id)); delete m.proposta; m.rodadaAval = m.rodadaAval || {}; m.rodadaAval[f] = (m.rodadaAval[f] || 1) + 1; m.passo = { t: 'lista', f }; });
  },
  voltarLista: () => gravarReuniao(m => { const veioDoQuadro = !!m.proposta; delete m.proposta; m.passo = veioDoQuadro ? { t: 'quadro', f: m.passo.f } : { t: 'lista', f: m.passo.f }; }),
  irObservacoes: () => gravarReuniao(m => { const f = m.passo.f; m.rodadaAval = m.rodadaAval || {}; m.rodadaAval[f] = m.rodadaAval[f] || 1; m.passo = { t: 'observacoes', f, i: 0 }; }),
  irQuadro: () => irPara({ t: 'quadro', f: S.M.passo.f }),
  marcarDeNovo: () => gravarReuniao(m => { const f = m.passo.f; m.rodadaAval = m.rodadaAval || {}; m.rodadaAval[f] = (m.rodadaAval[f] || 1) + 1; m.passo = { t: 'observacoes', f, i: 0 }; }),
  avaliar: async el => {
    const f = S.M.passo.f, ra = S.M.rodadaAval?.[f] || 1, c = el.dataset.c, k = el.dataset.k, v = +el.dataset.v;
    const id = `av_${f}_${ra}_${c}_${S.uid}`;
    const atual = entradas('av', f, ra).find(e => e.uid === S.uid && e.c === c) || { t: 'av', uid: S.uid, f, r: ra, c, a: null, b: null, ch: null, nc: false };
    const novo = { ...atual, [k]: k === 'nc' ? !!v : v };
    delete novo.id;
    S.E = S.E.filter(e => e.id !== id).concat([{ id, ...novo }]); render();
    await enviar(S.backend.setEntry(S.code, id, novo));
  },
  obsProx: () => irPara({ ...S.M.passo, i: (S.M.passo.i || 0) + 1 }),
  obsAnt: () => irPara({ ...S.M.passo, i: Math.max(0, (S.M.passo.i || 0) - 1) }),
  irOracao: () => irPara({ t: 'oracao', f: S.M.passo.f }),
  voltarObs: () => irPara({ t: 'observacoes', f: S.M.passo.f, i: 0 }),
  abrirVoto: () => { const f = S.M.passo.f; const r = (S.M.rodadaVoto?.[f] || 0) + 1; S.ui.voto = null; S.ui.votos = new Set(); gravarReuniao(m => { m.rodadaVoto[f] = r; m.passo = { t: 'voto', f, r }; }); },
  marcarVoto: el => {
    const v = el.dataset.v, k = +el.dataset.k;
    if (k <= 1) { S.ui.voto = v; render(); return; }
    const sel = S.ui.votos;
    if (v === 'branco') { const tinha = sel.has('branco'); sel.clear(); if (!tinha) sel.add('branco'); render(); return; }
    sel.delete('branco');
    if (sel.has(v)) sel.delete(v);
    else if (sel.size >= k) { toast(`Para esta função são até ${k} nomes. Tire um antes de pôr outro.`); return; }
    else sel.add(v);
    render();
  },
  votar: async () => {
    const { f, r } = S.M.passo;
    const escolhas = S.ui.votos && S.ui.votos.size ? [...S.ui.votos] : (S.ui.voto ? [S.ui.voto] : []);
    if (!escolhas.length || minhaEntrada('vd', f, r)) return;
    await enviar(S.backend.addEntry(S.code, { t: 'v', f, r, escolhas }));
    await enviar(S.backend.setEntry(S.code, `vd_${f}_${r}_${S.uid}`, { t: 'vd', uid: S.uid, f, r }));
    S.ui.voto = null; S.ui.votos = new Set(); render();
  },
  apurar: () => {
    const { f, r } = S.M.passo;
    const n = entradas('vd', f, r).length, total = presentes().length;
    if (n < total && !confirm(`Faltam ${total - n} registros. Encerrar assim mesmo?`)) return;
    const votos = entradas('v', f, r), contagem = {};
    votos.forEach(v => (v.escolhas || [v.escolha]).forEach(x => { contagem[x] = (contagem[x] || 0) + 1; }));
    const k = Math.min(Math.max(1, vagasRestantes(f)), restantes(f).length);
    const aptos = Object.entries(contagem).filter(([v, q]) => v !== 'branco' && v !== 'nao' && q > votos.length / 2).sort((a, b) => b[1] - a[1]);
    let eleitos = aptos.slice(0, k), empate = false;
    if (aptos.length > k && aptos[k][1] === aptos[k - 1][1]) { const lim = aptos[k - 1][1]; eleitos = eleitos.filter(([, q]) => q > lim); empate = true; }
    eleitos = eleitos.map(([v]) => v);
    gravarReuniao(m => {
      const res = m.resultados[f] = m.resultados[f] || {};
      res.escolhidos = res.escolhidos || []; res.adiada = false;
      res.ultima = { eleitos, empate, contagem, total: votos.length, rodada: r };
      eleitos.forEach(id => { if (!res.escolhidos.some(e => e.id === id)) res.escolhidos.push({ id, anuencia: 'pendente' }); });
      m.passo = { t: 'resultado', f };
    });
  },
  quemConversa: el => gravarReuniao(m => { const e = m.resultados[m.passo.f].escolhidos.find(x => x.id === el.dataset.id); if (e) e.quemConversa = el.dataset.n; }),
  vagas: el => gravarReuniao(m => { const f = m.funcoes.find(x => x.id === m.passo.f); f.vagas = Math.min(15, Math.max(1, (f.vagas || 1) + +el.dataset.d)); }),
  maisUm: () => { const f = S.M.passo.f; restantes(f).length ? irPara({ t: 'lista', f }) : ACOES.abrirPropostas(); },
  proximaFuncao: () => irPara({ t: 'escolherFuncao' }),
  votarDeNovo: () => irPara({ t: 'oracao', f: S.M.passo.f }),
  adiar: () => gravarReuniao(m => { const res = m.resultados[m.passo.f] = m.resultados[m.passo.f] || {}; res.ultima = null; res.adiada = !(res.escolhidos || []).length; m.passo = { t: 'escolherFuncao' }; }),
  irFim: () => irPara({ t: 'fim' }),
  anuencia: el => gravarReuniao(m => { const e = m.resultados[el.dataset.f].escolhidos.find(x => x.id === el.dataset.id); if (e) e.anuencia = el.dataset.s; }),
  copiarRelatorio: async () => {
    const t = relatorioTexto();
    try { await navigator.clipboard.writeText(t); } catch (e) { const ta = document.getElementById('relTexto'); ta.classList.remove('sr'); ta.select(); document.execCommand('copy'); ta.classList.add('sr'); }
    S.ui.copiado = true; render(); setTimeout(() => { S.ui.copiado = false; render(); }, 2000);
  },
  apagarReuniao: async () => {
    if (!confirm('Apagar todos os dados desta reunião do servidor? O relatório fica só neste aparelho.')) return;
    const arq = JSON.parse(localStorage.getItem('relatorios') || '[]');
    arq.push({ data: new Date().toISOString(), igreja: S.M.igreja, texto: relatorioTexto() });
    localStorage.setItem('relatorios', JSON.stringify(arq));
    apagarNotasLocais();
    await S.backend.deleteMeeting(S.code);
  },
  apagarNotas: () => { apagarNotasLocais(); toast('Anotações apagadas deste celular.'); }
};
function apagarNotasLocais() { Object.keys(localStorage).filter(k => k.startsWith('nota:' + S.code)).forEach(k => localStorage.removeItem(k)); }

// Sugestão de corte: mantém mais ou menos a metade mais marcada, nunca corta empate, tira quem ninguém marcou.
function sugerirCorte(ids, cons, k = 1) {
  const n = {}; ids.forEach(id => n[id] = cons[id] ? cons[id].nota : null);
  const ordem = [...ids].sort((a, b) => (n[b] ?? -1) - (n[a] ?? -1) || porNome(nomeDe(a), nomeDe(b)));
  const comNota = ordem.filter(id => n[id] !== null);
  if (!comNota.length) return { ordem, fica: ordem, notas: n };
  const alvo = Math.min(comNota.length, Math.max(2, k + 1, Math.ceil(ids.length / 2)));
  let corte = alvo; const limite = n[comNota[corte - 1]];
  while (corte < comNota.length && n[comNota[corte]] === limite) corte++;
  return { ordem, fica: comNota.slice(0, corte), notas: n };
}

function toast(msg) {
  let t = document.getElementById('toast');
  if (!t) { t = document.createElement('div'); t.id = 'toast'; t.setAttribute('role', 'status'); document.body.appendChild(t); }
  t.textContent = msg; t.classList.add('ver'); clearTimeout(t._h); t._h = setTimeout(() => t.classList.remove('ver'), 2600);
}

/* ======================= EVENTOS ======================= */
document.addEventListener('click', async ev => {
  const el = ev.target.closest('[data-a]');
  if (!el || el.disabled) return;
  const fn = ACOES[el.dataset.a];
  if (!fn) return;
  if (el.dataset.a !== 'recarregar') S.ui.erro = '';
  el.classList.add('ocupado');
  try { await fn(el); } catch (e) { console.error(e); toast('Não foi possível agora. Confira a internet e tente de novo.'); }
  finally { el.classList.remove('ocupado'); }
});
document.addEventListener('input', ev => {
  const el = ev.target;
  if (el.id === 'buscaNome') { S.ui.busca = el.value; render(); }
  else if (el.id === 'buscaServe') { S.ui.buscaServe = el.value; render(); }
  else if (el.id === 'membrosIn') { S.ui.wiz.membrosTexto = el.value; const c = document.getElementById('contaMembros'); if (c) c.textContent = plural(linhasValidas(el.value).length, 'nome', 'nomes'); }
  else if (el.id === 'novaFuncaoIn') S.ui.novaFuncao = el.value;
  else if (el.id === 'nomeIn') S.ui.nomeDigitado = el.value;
  else if (el.id === 'codigoIn') S.ui.codigoDigitado = el.value;
  else if (el.dataset.nota) localStorage.setItem(el.dataset.nota, el.value);
});
document.addEventListener('keydown', ev => {
  if (ev.key !== 'Enter' || ev.target.tagName === 'TEXTAREA') return;
  const map = { nomeIn: 'entrarReuniao', codigoIn: 'entrarReuniao', presNomeIn: 'wizIgreja', igrejaIn: 'wizIgreja', novaFuncaoIn: 'addFuncao' };
  const a = map[ev.target.id]; if (a) { ev.preventDefault(); ACOES[a](); }
});

iniciar().catch(e => console.error(e));
