import asyncio, re
from playwright.async_api import async_playwright
URL='http://localhost:8765/index.html'
async def click(pg,txt):
    await pg.get_by_role('button',name=re.compile(txt)).first.click(); await pg.wait_for_timeout(250)
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(); ctx=await b.new_context(viewport={'width':390,'height':844})
        erros=[]; pres=await ctx.new_page(); pres.on('pageerror',lambda e:erros.append(str(e)))
        await pres.goto(URL); await click(pres,'Só experimentar'); await click(pres,'Conduzir')
        await pres.screenshot(path='shots/o1_tipo.png')
        await click(pres,'^Comissão organizadora')
        await pres.fill('#igrejaIn','Igreja de Mortugaba'); await pres.fill('#presNomeIn','João'); await click(pres,'^Seguir')
        await pres.screenshot(path='shots/o2_funcoes.png'); await click(pres,'^Seguir')
        await pres.fill('#membrosIn','\n'.join(['Ana','Bia','Caio','Davi','Edu','Flor'])); await click(pres,'^Seguir')
        await pres.screenshot(path='shots/o3_membros_aviso.png')
        await click(pres,'Próxima função'); await click(pres,'Criar a reunião'); await pres.wait_for_timeout(400)
        code=(await pres.locator('.codigo').inner_text()).replace(' ','')
        m=await ctx.new_page(); m.on('pageerror',lambda e:erros.append(str(e)))
        await m.goto(f'http://localhost:8765/index.html?r={code}#teste'); await m.fill('#nomeIn','Rute'); await click(m,'^Entrar')
        await click(pres,'Começar'); 
        for i in range(7): await click(pres,'^Seguir')
        await click(pres,'^Membros da comissão'); await pres.screenshot(path='shots/o4_funcao.png')
        await click(pres,'Abrir as propostas')
        for pg in [pres,m]:
            for n in ['Ana','Caio']: await pg.locator('.nomes .nomeBtn',has_text=n).first.click()
            await click(pg,'^Enviar')
        await click(pres,'Ver a lista'); await click(pres,'Observar com atenção|Começar as observações')
        while await pres.get_by_role('button',name='Próximo nome').count(): await click(pres,'Próximo nome')
        await click(pres,'Ver o quadro'); await click(pres,'Ir para a oração'); await click(pres,'Abrir o discernimento secreto')
        for pg in [pres,m]: await pg.locator('.votos .voto',has_text='Ana').first.click(); await click(pg,'Confirmar o que discerni')
        await click(pres,'Mostrar o resultado'); await pres.wait_for_timeout(300)
        await pres.screenshot(path='shots/o5_resultado.png',full_page=True)
        await click(pres,'Próxima função'); await click(pres,'Encerrar por hoje'); await click(pres,'Copiar o relatório')
        rel=await pres.evaluate("document.getElementById('relTexto').value")
        print(rel); print('erros',erros); await b.close()
asyncio.run(main())
