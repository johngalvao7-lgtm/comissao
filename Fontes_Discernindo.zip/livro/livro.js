const fs = require('fs');
const D = require('docx');
const { Document, Packer, Paragraph, TextRun, AlignmentType, PageBreak, Footer, PageNumber, LevelFormat, HeadingLevel, BorderStyle, TabStopType, Table, TableRow, TableCell, WidthType, ShadingType } = D;

const TINTA = '1D2721', OURO = '8A6214', SALVIA = '56665C', FONTE = 'Georgia', SANS = 'Helvetica Neue';
const textos = JSON.parse(fs.readFileSync(__dirname + '/../textos.json', 'utf8'));
const corpo = [];
const push = (...x) => corpo.push(...x);

// texto com **negrito**
function runs(t, base = {}) {
  return t.split(/(\*\*[^*]+\*\*)/).filter(Boolean).map(s => s.startsWith('**')
    ? new TextRun({ text: s.slice(2, -2), bold: true, ...base })
    : new TextRun({ text: s, ...base }));
}
const p = (t, o = {}) => new Paragraph({ children: runs(t, o.run || {}), spacing: { after: o.after ?? 140, line: 312 }, alignment: o.align, indent: o.indent, keepNext: o.keepNext });
const nota = t => p(t, { run: { color: SALVIA, size: 19 }, after: 120 });
const rot = t => new Paragraph({ children: [new TextRun({ text: t, bold: true, color: OURO, size: 18, font: SANS, characterSpacing: 10 })], spacing: { before: 160, after: 60 }, keepNext: true });
const item = (t, nivel = 0) => new Paragraph({ children: runs(t), numbering: { reference: 'pontos', level: nivel }, spacing: { after: 80, line: 300 } });
const num = (t, ref = 'numeros') => new Paragraph({ children: runs(t), numbering: { reference: ref, level: 0 }, spacing: { after: 90, line: 300 } });
function citacao(t, ref, notaTxt) {
  const out = [new Paragraph({
    children: [new TextRun({ text: t, size: 22 })],
    border: { left: { style: BorderStyle.SINGLE, size: 18, color: OURO, space: 10 } },
    indent: { left: 240 }, spacing: { before: 60, after: 40, line: 300 }, keepNext: true
  }), new Paragraph({
    children: [new TextRun({ text: ref, color: OURO, size: 17, font: SANS })].concat(notaTxt ? [new TextRun({ text: '   ' + notaTxt, color: SALVIA, size: 17, italics: true })] : []),
    indent: { left: 240 + 190 }, spacing: { after: 200 }
  })];
  return out;
}
function tabela(linhas, cab = ['Quando', 'O quê', 'Quem'], W = [1900, 4686, 2200]) {
  const borda = { style: BorderStyle.SINGLE, size: 4, color: 'D3DBD5' };
  const cel = (t, w, cab, ultima) => new TableCell({ width: { size: w, type: WidthType.DXA }, margins: { top: 70, bottom: 70, left: 100, right: 100 },
    shading: cab ? { type: ShadingType.CLEAR, fill: 'F1E5C6', color: 'auto' } : undefined,
    borders: { top: borda, bottom: borda, left: borda, right: borda },
    children: [new Paragraph({ children: runs(t, { size: 19, bold: !!cab }), spacing: { after: 0, line: 276 }, keepNext: !ultima })] });
  push(new Table({ width: { size: 8786, type: WidthType.DXA }, columnWidths: W,
    rows: [new TableRow({ tableHeader: true, children: cab.map((t, i) => cel(t, W[i], true)) })].concat(linhas.map((l, k) => new TableRow({ cantSplit: true, children: l.map((t, i) => cel(t, W[i], false, k === linhas.length - 1)) }))) }));
  push(new Paragraph({ spacing: { after: 120 } }));
}
function parte(numero, titulo, sub) {
  push(new Paragraph({ pageBreakBefore: true, children: [new TextRun({ text: numero, color: OURO, size: 20, font: SANS, bold: true })], spacing: { before: 600, after: 80 }, keepNext: true }));
  push(new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun({ text: titulo })], spacing: { after: 160 } }));
  if (sub) push(p(sub, { run: { color: SALVIA, size: 23 }, after: 360 }));
}
const passo = (n, t) => push(new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun({ text: `${n}  `, color: OURO }), new TextRun({ text: t })], spacing: { before: 420, after: 120 }, keepNext: true }));
const sub = t => push(new Paragraph({ heading: HeadingLevel.HEADING_3, children: [new TextRun(t)], spacing: { before: 280, after: 100 }, keepNext: true }));
function bloco(o) {
  if (o.agora) { push(rot('AGORA')); [].concat(o.agora).forEach(x => push(p(x))); }
  if (o.leia) { push(rot('LEIA EM VOZ ALTA')); o.leia.forEach(([t, r]) => push(...citacao(t, r))); }
  if (o.celular) { push(rot('NO CELULAR')); push(p(o.celular)); }
  if (o.porque) { push(rot('POR QUÊ')); push(p(o.porque, { run: { color: SALVIA } })); }
}

/* ===================== CAPA ===================== */
push(new Paragraph({ spacing: { before: 2600 } }));
push(new Paragraph({ children: [new TextRun({ text: 'Discernindo', size: 76, color: TINTA })], spacing: { after: 0 } }));
push(new Paragraph({ children: [new TextRun({ text: 'a vontade de Deus', size: 76, color: TINTA })], spacing: { after: 360 } }));
push(new Paragraph({ children: [new TextRun({ text: 'A comissão de nomeações, passo a passo', size: 30, color: OURO })], spacing: { after: 2400 } }));
push(p('Para o presidente e os membros da comissão de nomeações da igreja local.', { run: { color: SALVIA } }));
push(p('Com os escritos de Ellen G. White e as regras do Manual da Igreja.', { run: { color: SALVIA } }));
push(p('Pr. João Galvão · Distrito de Condeúba, Bahia · outubro de 2026', { run: { color: SALVIA, size: 19 } }));

/* ===================== 1. COMO USAR ===================== */
parte('PARTE 1', 'Como usar este livro');
push(p('Primeiro a igreja escolhe os seus Samueis: as pessoas da comissão de nomeações. Depois, como Samuel na casa de Jessé, os Samueis não decidem pelo que veem. Eles escutam.'));
push(...citacao('Porque o Senhor não vê como vê o homem, pois o homem vê o que está diante dos olhos, porém o Senhor olha para o coração.', '1 Samuel 16:7'));
push(p('Este livro conduz a eleição dos oficiais do começo ao fim: desde o primeiro sermão até a posse. Nas reuniões, quem preside lê cada passo. Os membros acompanham no próprio celular, no site da comissão, e a tela de todos muda junto. Ninguém precisa decorar nada.'));
push(p('Cada passo tem quatro partes:'));
push(item('**Agora:** o que fazer neste momento.'));
push(item('**Leia em voz alta:** um texto curto, que todos também veem no celular.'));
push(item('**No celular:** o que aparece na tela de cada um.'));
push(item('**Por quê:** a razão, numa linha.'));
push(p('Sem celular ou sem internet, tudo acontece do mesmo jeito, em papel (Parte 7).'));
sub('O caminho inteiro');
push(num('**Antes da comissão:** a igreja se prepara, as classes indicam, a igreja vota a organizadora, e a organizadora discerne a comissão de nomeações (Parte 3).'));
push(num('**A comissão:** o presidente prepara a reunião (Parte 4) e a comissão discerne os oficiais, uma função de cada vez (Parte 5).'));
push(num('**Depois da comissão:** a anuência, as duas leituras, as objeções, o voto e a posse (Parte 6).'));
push(p('As datas de tudo isso estão na Parte 2.'));
push(p('Os textos de Ellen White aparecem curtos durante a reunião. A versão completa está na Parte 9, para estudar com calma, de preferência antes do dia.'));


/* ===================== 2. CALENDÁRIO ===================== */
parte('PARTE 2', 'O calendário', 'Um exemplo para quem tem o mandato terminando em 31 de dezembro de 2026. As datas em negrito são prazos do Manual; as outras podem andar.');
push(p('O Manual pede duas coisas: que a comissão de nomeações seja formada no começo do último trimestre do mandato, e que ela apresente o relatório pelo menos três semanas antes do último sábado do período. A igreja vota o relatório uma ou duas semanas depois da primeira leitura (Manual da Igreja, cap. 10).'));
tabela([
  ['Sáb 3 e 10/out', 'Preparar a igreja: sermão e estudo sobre 1 Samuel 16 e Atos 1', 'Pastor ou ancião'],
  ['Sáb 10/out', 'Apresentar o assunto; a igreja escolhe o jeito de formar a organizadora e o tamanho da comissão', 'Pastor ou, na ausência, o ancião'],
  ['Sáb 17/out', 'As classes indicam, na Escola Sabatina', 'Professores'],
  ['Sex 23/out', 'Contar as indicações; pedir a concordância de cada um', 'Secretário, mais um membro e o pastor'],
  ['Sáb 24/out', 'A igreja vota a organizadora; ela se reúne à tarde', 'Igreja e organizadora'],
  ['**Sáb 31/out**', '**A igreja vota a comissão de nomeações e o quórum**', 'Igreja'],
  ['1 a 29/nov', 'Reuniões da comissão: sábado à tarde ou domingo à tarde', 'Comissão de nomeações'],
  ['Até 4/dez', 'Anuência de cada pessoa escolhida', 'Quem a comissão designou'],
  ['**Sáb 5/dez**', '**Primeira leitura (prazo: três semanas antes de 26/dez)**', 'Secretário da comissão'],
  ['5 a 11/dez', 'Semana de observações; a comissão ouve as objeções', 'Comissão'],
  ['Sáb 12/dez', 'Segunda leitura e voto', 'Igreja'],
  ['Sáb 19/dez', 'Reserva, se o relatório voltar à comissão', '—'],
  ['Sáb 2/jan/2027', 'Posse dos oficiais', 'Pastor']
]);
push(nota('Este é o jeito de várias semanas. Para fazer tudo num sábado, veja mais abaixo. Junto com este livro vai um arquivo de calendário (Eleicoes_2026.ics). Toque nele no iPhone e as datas entram no seu calendário.'));
push(new Paragraph({ heading: HeadingLevel.HEADING_3, pageBreakBefore: true, children: [new TextRun('Dez igrejas, um pastor')], spacing: { after: 100 }, keepNext: true }));
push(p('Um pastor não consegue presidir dez comissões de nomeações em quatro semanas de novembro. O Manual prevê o caminho: se o pastor preferir não presidir, a organizadora recomenda um presidente entre os membros da comissão (Manual da Igreja, cap. 10). Presida onde a sua presença mais pesa. Nas outras, a organizadora recomenda um ancião que já tenha conduzido uma reunião de teste com este livro e o site.'));
push(p('Para as reuniões, prefira sábado à tarde ou domingo à tarde. Segunda-feira, não.'));
sub('Para distritos grandes: tudo num sábado');
push(p('É o jeito das assembleias: os mesmos passos, num só dia. A organizadora trabalha enquanto a igreja estuda a lição da Escola Sabatina; no fim do culto, a igreja vota a comissão de nomeações; depois do almoço, a comissão começa. Assim cabe uma igreja por sábado: de 17 de outubro a 28 de novembro são sete sábados. Nas igrejas que sobrarem, conduz um ancião treinado.'));
push(p('**Por que durante a lição, e não durante o sermão.** No jeito 2, a organizadora inclui a Comissão Diretiva: o pastor e os anciãos, que costumam conduzir o culto. Durante a lição, ninguém deixa o púlpito vazio e ninguém perde o culto. Por isso as classes indicam no sábado anterior, e a igreja vota a organizadora numa reunião curta antes da Escola Sabatina.'));
tabela([
  ['Semanas antes', 'Preparar a igreja (Parte 3, passo 1)', 'Pastor ou ancião'],
  ['Sábado anterior', 'As classes indicam, nos primeiros dez minutos da Escola Sabatina. No culto, a igreja vota o jeito, o tamanho da comissão e o dia, e é avisada da reunião curta do sábado seguinte', 'Professores; pastor ou ancião'],
  ['Durante a semana', 'Contar as indicações e pedir a concordância de cada um. Preparar a lista de membros aptos', 'Secretário, mais um membro e o pastor; tesoureiro'],
  ['Antes da Escola Sabatina', 'Reunião curta da igreja: vota a organizadora (cinco minutos)', 'Igreja'],
  ['Durante a lição', 'A organizadora se reúne à parte e discerne a comissão de nomeações no site (uns 45 minutos). O presidente já conversa com os escolhidos ao sair', 'Organizadora'],
  ['Fim do culto', 'A igreja vota a comissão de nomeações e o quórum (cinco minutos)', 'Igreja'],
  ['À tarde, depois do almoço', 'A comissão de nomeações começa (Parte 5), por no máximo duas horas e meia. O que não couber fica para domingo à tarde ou o sábado seguinte', 'Comissão'],
  ['Semana seguinte', 'Anuência de cada pessoa escolhida', 'Quem a comissão designou'],
  ['Depois', 'Primeira leitura; uma semana depois, segunda leitura e voto (até os prazos do Manual)', 'Igreja']
]);
push(nota('Se a organizadora não terminar no tempo da lição, continua no almoço, e a igreja vota a comissão numa reunião curta depois do almoço.'));
push(p('**O cuidado deste jeito é a pressa.** Ela fica do lado de fora assim: a igreja se prepara nas semanas antes, as listas chegam prontas, a comissão tem hora para parar, e nada se decide sem oração. Se a comissão sentir que precisa de mais tempo, continua outro dia, com o mesmo código.'));

/* ===================== 3. ANTES DA COMISSÃO ===================== */
parte('PARTE 3', 'Antes da comissão: a igreja escolhe os seus Samueis', 'Do primeiro sermão até a igreja votar a comissão de nomeações. Sete passos, em umas quatro semanas, ou do passo 3 ao 7 num único sábado (Parte 2).');
passo('1', 'Preparar a igreja');
bloco({ agora: 'Num ou dois sábados, pregue ou estude com a igreja 1 Samuel 16 e Atos 1. A pergunta de fundo: como a igreja escuta a escolha de Deus?',
  leia: [['Porque o Senhor não vê como vê o homem, pois o homem vê o que está diante dos olhos, porém o Senhor olha para o coração.', '1 Samuel 16:7'],
    ['Devemos apresentar a Deus cada caso, e, com oração fervorosa, pedir-Lhe que escolha por nós.', 'T9 264.1']],
  porque: 'Quando a igreja inteira entende o porquê, a eleição deixa de ser formalidade e as indicações saem mais limpas.' });
passo('2', 'Apresentar o assunto e escolher o jeito');
bloco({ agora: 'No culto, o pastor (ou, na ausência dele, o ancião) apresenta o assunto. A igreja escolhe um dos dois jeitos do Manual para formar a comissão organizadora, e vota. Na mesma ocasião, a igreja vota o tamanho da comissão de nomeações, que a Comissão Diretiva estudou antes: cinco pessoas numa igreja pequena, mais numa igreja grande.',
  porque: 'Decidir o jeito antes de começar evita discussão no meio do processo.' });
push(p('**Jeito 1.** Toda a igreja indica os nomes da organizadora, que terá de cinco a sete pessoas a mais que a Comissão Diretiva.'));
push(p('**Jeito 2 (o que este livro sugere).** A organizadora é a própria Comissão Diretiva, mais cinco a sete pessoas escolhidas pela igreja. Dá o mesmo tamanho, com uma votação a menos, e a Comissão Diretiva já foi escolhida pela igreja. As classes indicam essas cinco a sete pessoas.'));
push(nota('Nos dois jeitos, o pastor preside a organizadora. No jeito 2, quem preside é o presidente da Comissão Diretiva, normalmente o pastor (Manual da Igreja, cap. 10).'));
passo('3', 'As classes indicam');
bloco({ agora: ['No sábado combinado, nos primeiros minutos da Escola Sabatina, cada professor entrega a cada membro batizado da classe a folha de indicação da classe (modelo na Parte 7): a lista dos membros daquela classe, com um quadradinho ao lado de cada nome.',
    'Em oração e em silêncio, cada um marca até dois nomes da própria classe: as pessoas que discerne que Deus está chamando para ajudar a formar a comissão de nomeações. Dobra a folha e devolve. O professor fecha tudo num envelope e entrega ao secretário da igreja, sem abrir.'],
  leia: [['Chamem-se homens de responsabilidade para escolher os oficiais da igreja.', 'ME2 328.6'],
    ['Cada membro da igreja tem participação na escolha dos oficiais da igreja.', 'LC 59.2']],
  porque: 'Na classe, cada um conhece de perto quem estuda ao seu lado toda semana. E como as classes costumam ser por idade, as indicações já trazem gente de todas as idades.' });
push(nota('Se não der para preparar as folhas com os nomes, cada membro recebe um papel em branco e escreve, em oração, até dois nomes de pessoas da própria classe. Na contagem, junte as grafias diferentes do mesmo nome.'));
passo('4', 'Contar e pedir a concordância');
bloco({ agora: ['Numa sexta-feira à tarde, o secretário e mais um membro abrem os envelopes juntos e contam as marcas de cada classe. A regra é simples: entra a pessoa mais indicada de cada classe; depois, completa-se até cinco a sete pessoas com as mais indicadas das classes, na ordem das marcas.',
    'Confiram o equilíbrio: idades diferentes, homens e mulheres, nada de muitas pessoas da mesma família. Em seguida, o pastor ou o ancião conversa com cada uma e pergunta se aceita servir.'],
  porque: 'A contagem não é anunciada a ninguém. Assim ninguém se sente medido, e nenhum grupo ganha força por número.' });
passo('5', 'A igreja vota a organizadora');
bloco({ agora: 'No culto, usando pouco tempo, o pastor lê os nomes. Se alguém quiser propor outro nome, propõe um só (Manual da Igreja, cap. 10). A igreja vota.',
  porque: 'As classes indicam; quem escolhe é a igreja reunida. Isso guarda o que o Manual pede e evita qualquer aspecto político.' });
passo('6', 'A organizadora discerne a comissão de nomeações');
bloco({ agora: 'A organizadora se reúne logo, de preferência na mesma tarde. A reunião segue os mesmos passos da Parte 5, usando o site: ao conduzir, escolha **Comissão organizadora**. As funções já vêm prontas: membros da comissão de nomeações e o secretário.',
  celular: 'Os mesmos passos de sempre. Depois de cada nome discernido, aparece o quadro de equilíbrio: quantos nomes já foram escolhidos e o lembrete do Manual.',
  porque: 'O Manual pede representação justa: diferentes idades, homens e mulheres, e no máximo duas pessoas do mesmo núcleo familiar. Só membros em situação regular. Pessoas de bom senso, que tenham no coração o bem da igreja (Manual da Igreja, cap. 10).' });
push(nota('O pastor é membro da comissão de nomeações e a preside, sem precisar ser votado. Se ele preferir não presidir, a organizadora recomenda um presidente entre os membros da comissão.'));
passo('7', 'A igreja vota a comissão de nomeações');
bloco({ agora: 'No culto seguinte, o pastor lê os nomes e o secretário recomendados. A igreja vota a comissão e, junto, o quórum: sugerimos mais da metade dos membros da comissão. A comissão se reúne o quanto antes.',
  porque: 'O quórum votado antes evita dúvida no dia em que alguém faltar.' });

/* ===================== 4. PREPARAR ===================== */
parte('PARTE 4', 'Preparar a reunião da comissão', 'Para o presidente da comissão. Uns trinta minutos, alguns dias antes.');
passo('A', 'Marque o dia, a hora de começar e a hora de terminar');
push(p('Combine com a comissão um horário que deixe todos descansados. Duas horas costumam bastar para várias funções. O que não couber fica para outro dia, com o mesmo código.'));
push(...citacao('Ofereçam repouso ao cérebro cansado. Trabalhar demais é destrutivo para as faculdades físicas, mentais e morais.', 'T7 256.2'));
passo('B', 'Prepare a lista de quem pode ser proposto');
push(p('Com o secretário e o tesoureiro, em particular, faça a lista de membros que podem receber cargo: membros regulares desta igreja e fiéis no dízimo. É o que o Manual pede, com a maior confidencialidade possível (Manual da Igreja, cap. 10).'));
push(p('Escreva um nome por linha, no aplicativo Notas. Na reunião, você vai colar essa lista no site. Ninguém verá quem ficou de fora, nem por quê.'));
push(nota('Se não der para preparar a lista a tempo, faça a reunião em papel (Parte 7): cada um escreve os nomes que discerne. Antes de pedir a anuência, o presidente confere em particular, com o tesoureiro e o secretário, se cada pessoa escolhida pode receber cargo.'));
passo('C', 'Anote quem serve hoje em cada função');
push(p('O site vai perguntar. Isso só serve para mostrar, com discrição, quem já está na função. Não tira ninguém da conversa.'));
push(p('Os professores da Escola Sabatina não entram: quem os indica é a comissão da Escola Sabatina (Manual da Igreja, cap. 10).'));
passo('D', 'Convide a comissão a se preparar');
push(p('Mande uma mensagem curta, uns dois dias antes. Um modelo:'));
push(p('“Irmãos, nossa reunião da comissão de nomeações será em [dia], às [hora], até [hora]. Antes de vir, vamos orar e sondar o nosso coração. Venham com o celular carregado. Uma refeição leve antes ajuda a mente a discernir. Se puderem, leiam a Parte 9 do livro.”', { indent: { left: 360 }, run: { color: SALVIA } }));
push(...citacao('Antes de nossos irmãos se reunirem em concílio ou reuniões de comissão, deve cada um apresentar-se perante Deus, perscrutando cuidadosamente o coração e examinando-lhe rigorosamente os motivos.', 'T7 257.1'));
passo('E', 'No celular ou no Mac, prepare a reunião');
push(p('Abra o site da comissão e toque em **Conduzir uma reunião**. Escolha **Comissão de nomeações** e responda: quais funções, quem pode ser proposto (cole a lista do passo B) e quem serve hoje. No fim, aparece o QR code da reunião. Pode fazer isso em casa, antes do dia.'));

/* ===================== 3. A REUNIÃO ===================== */
parte('PARTE 5', 'A reunião da comissão, passo a passo', 'Os passos 1 a 4 acontecem uma vez. Os passos 5 a 9 se repetem para cada função. O passo 10 fecha.');

passo('1', 'Chegada');
bloco({ agora: 'Mostre o QR code na tela do seu celular. Cada membro aponta a câmera, abre o link e escreve o primeiro nome. Quem não conseguir ler o QR recebe o link pelo WhatsApp (há um botão para isso).',
  celular: 'Você vê quem já entrou. Quando todos estiverem, toque em **Começar a reunião**.',
  porque: 'Cada um com o próprio celular deixa as propostas e o voto realmente secretos.' });

passo('2', 'Oração');
bloco({ agora: 'Peça que alguém ore em voz alta, pedindo que Cristo presida a reunião.',
  leia: [['Pediu-se em oração que Cristo presidisse à reunião, e comunicasse Sua sabedoria, Sua graça e justiça.', 'OE 448.1']],
  celular: 'O mesmo texto. Depois da oração, toque em **Seguir**.',
  porque: 'Quem escolhe é Deus. A reunião começa entregando a direção a Ele.' });

passo('3', 'Quatro combinados');
bloco({ agora: 'Leia os quatro combinados e confirme a hora de terminar.',
  leia: [['Conservemos em mente que Jesus Se acha em nosso meio.', 'OE 448.2'],
    ['Nada de espírito “indiferente, endurecido, crítico, não amoroso”.', 'T7 256.2'],
    ['Todas as consultas e discussões da comissão são confidenciais.', 'Manual da Igreja, cap. 10'],
    ['Ofereçam repouso ao cérebro cansado.', 'T7 256.2']],
  porque: 'Combinar antes evita ter que corrigir alguém no meio da conversa.' });

passo('4', 'Cinco frases para lembrar');
bloco({ agora: 'Leia uma frase por vez. Cinco minutos, no máximo. Quem quiser aprofundar, lê a Parte 9 em casa.',
  leia: [['Devemos apresentar a Deus cada caso, e, com oração fervorosa, pedir-Lhe que escolha por nós.', 'T9 264.1'],
    ['Ao dar conselho para o avanço da obra, homem nenhum sozinho deve ser um poder dominante, uma voz por todos.', 'T7 259.1'],
    ['É muito melhor provar o homem antes de receber um cargo do que depois.', 'T5 618.1'],
    ['Sobretudo, escolhei os que, na simplicidade de sua alma, estejam andando na verdade, que amem e temam a Deus, e aprendam em Sua escola.', 'CES 165.1'],
    ['Lançar sortes para os oficiais da igreja não está no plano de Deus. Chamem-se homens de responsabilidade para escolher os oficiais da igreja.', 'ME2 328.6']],
  porque: 'Quem escolhe é Deus; todos pesam; sem pressa; sobretudo gente que anda com Deus; nem sorte, nem gosto pessoal.' });

passo('5', 'A função e o que Deus pede');
bloco({ agora: 'No seu aparelho, toque na função que a comissão vai considerar. Leia em voz alta as características que aparecem. Logo abaixo, diga quantas pessoas a comissão vai discernir para essa função: anciãos, diáconos e diaconisas costumam ser mais de uma.',
  celular: 'Todos veem o nome da função, as características e um texto. O quadro abaixo mostra o que aparece para cada tipo de função.',
  porque: 'Primeiro se olha o que Deus pede. Só depois se pensa em nomes.' });
sub('O que aparece para cada função');
const tipos = [
  ['Anciãos', 'Vida limpa e boa reputação, também em casa (Tito 1:5-7; T5 617-618). Comunhão viva com Deus, tato e bom senso (T5 618.2). Sabe dar a cada membro uma parte no trabalho (SC 46.6). Cuida dos fracos e dos que se afastaram (CES38 84.2).'],
  ['Diáconos e diaconisas', 'Boa reputação; cheio do Espírito Santo e de sabedoria (Atos 6:3). Cuida dos fracos e dos que se afastaram (CES38 84.2).'],
  ['Secretário(a) e tesoureiro(a)', 'Fidelidade comprovada no que lhe é confiado (1 Coríntios 4:2). Comunhão viva com Deus (T5 618.2).'],
  ['Escola Sabatina', 'Anda na verdade, ama e teme a Deus, aprende em Sua escola (CES 165.1). Guiado pelo Espírito Santo (TS2 564.1). Tato, ânimo, capacidade de dirigir; estuda e pratica a Palavra (Conselhos sobre a Escola Sabatina).'],
  ['Ministério Pessoal', 'Inteiramente convertido; serve pela palavra e pelos atos; envolve os membros na missão (T6 85-86).'],
  ['Jovens, Desbravadores, Criança', 'Intimamente ligado a Deus; pronto para discernir e eficiente para fazer (CES 164.2). Guia os jovens por caminhos seguros (CES38 84.2-84.3).'],
  ['Outras funções de direção', 'Comunhão viva com Deus, tato e bom senso (T5 618.2). Diligente, zeloso e sem interesse próprio (T5 618-619). Inteiramente convertido (T6 85-86).']
];
tipos.forEach(([a, b]) => push(new Paragraph({ children: [new TextRun({ text: a + '.  ', bold: true }), new TextRun({ text: b })], spacing: { after: 110, line: 300 } })));
push(nota('Em todas, antes de tudo vem a pergunta principal: a pessoa anda com Deus? E escolha-se também entre as mulheres, onde a função permitir.'));

passo('6', 'Propostas, em silêncio');
bloco({ agora: 'Toque em **Abrir as propostas**. Peça um minuto de silêncio. Em oração, cada um traz, no próprio celular, quem percebe que Deus está chamando. Pode propor mais de um nome, ou nenhum.',
  celular: 'Cada um toca nos nomes da lista e envia. Ninguém vê quem propôs quem. O presidente vê só quantos já enviaram. Quando todos tiverem enviado, toque em **Ver a lista**: as propostas se juntam numa lista única, em ordem alfabética, sem nomes repetidos.',
  porque: 'Todos propõem antes de ouvir os outros. Assim nenhuma voz puxa as demais (T7 259.1).' });

passo('7', 'Observações sobre cada nome');
bloco({ agora: ['Toque em **Começar as observações**. Todos os nomes da lista passam por aqui, um de cada vez, desde a lista grande. Com a lista grande, um ou dois minutos por nome: quem souber de algum fato importante, fala. Com a lista pequena, com calma: cada um conta o que sabe que os outros talvez não saibam.',
    'Depois da conversa sobre cada nome, cada um marca em silêncio, no próprio celular, as três características que Deus revelou, em cinco níveis: excelente, muito bom, bom, precisa crescer um pouco, precisa crescer muito. Quem não conhece a pessoa o bastante toca em “Não conheço esta pessoa o bastante” e não marca.'],
  celular: 'O nome, as três características com o peso de cada uma, os botões de nível e um espaço para anotação pessoal, que fica só naquele celular. O presidente vê quantos já marcaram. Ninguém vê a marcação do outro.',
  porque: 'Quando os critérios entram desde a lista grande, ninguém sai da lista por gosto pessoal ou por falta de atenção: todos são vistos pelas mesmas características. Se for preciso perguntar algo a alguém de fora, quem pergunta é o presidente (Manual da Igreja, cap. 10).' });
sub('As três características e o peso de cada uma');
push(num('**Que ligação com Deus você percebe nesta pessoa?** Ama e teme a Deus, ora, vive a verdade com simplicidade (CES 165.1). Vale **70%**: é o que mais pesa.', 'perguntas'));
push(num('**O que Deus revelou para esta função, você percebe nela?** As características do passo 5. Vale **15%**.', 'perguntas'));
push(num('**Em sua consciência, você discerne que Deus a está chamando para esta função?** “O Senhor tem certos homens para ocupar determinados cargos” (T9 264.1). Vale **15%**.', 'perguntas'));
push(p('**E a experiência?** Não entra na nota. Já ter servido não pesa contra nem a favor; só ajuda a desempatar (passo 8).'));
sub('Como a nota é calculada');
push(p('O site faz a conta sozinho. No papel, cada nível vale os pontos abaixo; some as três linhas. A nota vai de 20 a 100.', { keepNext: true }));
tabela([
  ['Ligação com Deus (70%)', '70', '56', '42', '28', '14'],
  ['O que a função pede (15%)', '15', '12', '9', '6', '3'],
  ['O chamado que discirno (15%)', '15', '12', '9', '6', '3']
], ['Característica', 'Excelente', 'Muito bom', 'Bom', 'Crescer um pouco', 'Crescer muito'], [2386, 1300, 1300, 1100, 1350, 1350]);

passo('8', 'O quadro da comissão e o afinar da lista');
bloco({ agora: ['Depois do último nome, toque em **Ver o quadro da comissão**. Leia em voz alta o que aparece, sem comentar números de ninguém em particular.',
    'Se a lista ainda tiver mais de três nomes, toque em **Afinar a lista pela nota**. O site sugere manter mais ou menos a metade com as maiores notas, sem cortar empates; o presidente pode ajustar antes de confirmar. Depois, os nomes que ficaram passam de novo pelo passo 7, agora com mais atenção, e marcam-se de novo. Repita até ficarem dois ou três nomes.'],
  celular: 'A nota da comissão para cada nome, com uma barra. Com cinco marcações ou mais, a maior e a menor ficam de fora, e faz-se a média das outras; com menos de cinco, a média de todas. Dois avisos aparecem sozinhos, quando for o caso.',
  porque: 'A lista vai diminuindo pelos critérios que Deus revelou, e não por maioria nem por gosto. A maioria decide uma vez só: no voto, depois da oração.' });
push(p('**Percepções bem diferentes.** Se, sobre alguém, a maior e a menor nota ficam a mais de 30 pontos uma da outra, o site avisa: conversem e orem mais. Vocês podem tocar em **Marcar de novo** depois de conversar.'));
push(p('**Quase no mesmo nível.** Na lista pequena, se os dois primeiros ficam a 5 pontos ou menos um do outro e um deles já serve na função, o site lembra o princípio: fica quem anda mais perto de Deus, com chamado e habilidade, mesmo que já sirva; mas, quando duas pessoas estão no mesmo nível em tudo, e a única diferença é que uma já serviu, vale dar a vez à outra.'));

passo('9', 'Oração e voto secreto');
bloco({ agora: 'Toque em **Ir para a oração**. Um momento de silêncio. Depois, alguém ora entregando a decisão a Deus.',
  leia: [['Tu, Senhor, conhecedor dos corações de todos, mostra qual destes tens escolhido.', 'Atos 1:24']],
  celular: 'Toque em **Abrir o discernimento secreto**. A pergunta é: “Em sua consciência, quem você discerne ser a escolha de Deus para esta função?” Cada um toca num nome, ou em “Ainda não discerni”. Se houver um nome só, a pergunta é se discerne que aquela pessoa é a escolha de Deus: “Sim, discirno” ou “Ainda não discirno”. O resultado aparece quando todos tiverem votado.',
  porque: 'Primeiro se ora, depois se vota. A oração não é um enfeite antes do voto: é o voto que acompanha a oração.' });
sub('Quando alguém já serve nesta função');
push(p('Se entre os nomes houver alguém que já serve, o site mostra, na tela da oração, esta lembrança. Ela não manda em nada; só deixa o princípio claro para todos.'));
push(p('**Fica quem anda mais perto de Deus**, com chamado e habilidade para a função, mesmo que já sirva nela. A mesma pessoa pode ser reeleita “caso o seu serviço se tenha provado uma bênção para a igreja” (T5 619).'));
push(p('**Se duas pessoas estão no mesmo nível em tudo**, e a única diferença é que uma já serviu, vale dar a vez à outra: mentes diversas trazem novas ideias (Conselhos sobre a Escola Sabatina).'));
sub('Como se conta o voto');
push(p('Para decidir, um nome precisa de **mais da metade dos votos dados**. “Ainda não discerni” conta como voto dado.'));
push(p('Se ninguém tiver mais da metade, o site mostra “Ainda não há maioria” e oferece três caminhos: orar e votar de novo, conversar mais, ou deixar para outro dia. Isso não é fracasso. É sinal para orar mais, sem pressa.'));
sub('Funções com mais de uma pessoa');
push(p('Se a função pede, por exemplo, três anciãos, cada um pode tocar em até três nomes, e o site não deixa passar disso. Nas funções de uma pessoa só, só dá para tocar em um nome. Cada nome precisa de mais da metade dos votos para ser discernido. Se mais nomes passarem da metade do que as vagas, ficam os mais votados; se houver empate na última vaga, ela fica para uma nova oração.'));
sub('Quando a comissão discerne');
push(p('Escolha, ali mesmo, quem da comissão vai conversar com cada pessoa para pedir a anuência. Se ainda faltarem vagas, toque em **Discernir as vagas que faltam**: a comissão volta à lista, ora e discerne de novo, com os nomes que sobraram.'));

passo('10', 'Encerrar');
bloco({ agora: 'Na hora combinada, mesmo que faltem funções, toque em **Encerrar por hoje**. Ore agradecendo. O que faltou fica para outro dia, com o mesmo código.',
  celular: 'O presidente vê o que foi discernido, quem conversa com cada pessoa, e pode copiar o relatório. Cada membro pode apagar as próprias anotações.',
  porque: 'Decisões tomadas com a mente cansada saem precipitadas (T7 258.1).' });


/* ===================== 6. DEPOIS ===================== */
parte('PARTE 6', 'Depois da comissão: das leituras à posse', 'Seis passos, da conversa com cada pessoa até a oração de posse.');
passo('1', 'Pedir a anuência');
bloco({ agora: 'Quem a comissão designou visita cada pessoa escolhida. Explique a função, diga que a comissão orou e sentiu que Deus a está chamando, e pergunte se ela aceita. Se a pessoa quiser orar antes de responder, combine um dia, antes da primeira leitura.',
  celular: 'No relatório final do site, o presidente marca: aceitou, não aceitou ou aguardando. Se alguém não aceitar, a função volta para a comissão, com o mesmo código.',
  porque: 'Ninguém é apresentado à igreja sem saber e concordar (Manual da Igreja, cap. 10).' });
passo('2', 'Primeira leitura');
bloco({ agora: 'Num culto de sábado ou numa reunião administrativa, o presidente da comissão faz uma palavra breve e o secretário da comissão lê os nomes, ou entrega uma cópia a cada membro. Não se vota.',
  porque: 'A igreja precisa de tempo para olhar cada nome com calma, sem a pressão de votar na hora.' });
push(rot('O PRESIDENTE PODE DIZER'));
push(p('“Irmãos, a comissão de nomeações trabalhou em oração, pedindo que Deus mostrasse a Sua escolha. Estes são os nomes que ela recomenda. Hoje não vamos votar. Se alguém tiver uma razão séria para que algum nome seja revisto, procure pessoalmente o presidente da comissão ou o pastor até [dia]. No sábado [data], a igreja vai votar.”', { indent: { left: 360 }, run: { color: SALVIA } }));
passo('3', 'A semana de observações');
bloco({ agora: ['Quem tiver uma objeção marca uma conversa com o presidente da comissão ou com o pastor, antes da segunda leitura. O presidente anuncia quando e onde a comissão vai ouvir. Quem fez a objeção deve comparecer; seria grave adiar a eleição por uma objeção e a pessoa não aparecer.',
    'Depois de ouvir, e sem a pessoa na sala, a comissão ora, conversa e decide se mantém ou muda a recomendação. Registre na ficha de objeção (modelo na Parte 7).'],
  leia: [['Orem para que o Senhor lhes revele, de maneira que não critiquem nem condenem imprudentemente alguma proposta.', 'T7 257.1']],
  porque: 'Nunca se devem fazer objeções triviais ou infundadas; mas razões sérias devem ser ouvidas (Manual da Igreja, cap. 10). E o que se ouve fica em sigilo.' });
passo('4', 'Segunda leitura e voto');
bloco({ agora: 'O presidente da comissão lê de novo o relatório, já com as mudanças, se houve. A igreja vota o relatório. Decide a maioria dos que estiverem presentes e votarem; todos os membros devem votar.',
  porque: 'Duas leituras com uma semana entre elas dão à igreja o tempo que os escritos pedem: “sem que se conceda aos irmãos o tempo suficiente”, nada de propostas precipitadas (T9 278.1).' });
push(nota('Na segunda leitura, um membro pode pedir que o relatório volte à comissão, sem discussão. O normal é o presidente aceitar. Se o pedido virar uma proposta, ela não é debatida e é decidida por maioria (Manual da Igreja, cap. 10).'));
passo('5', 'Posse');
bloco({ agora: 'No primeiro sábado do novo mandato, durante o culto. Uns dez minutos.' });
push(num('**Chamada.** Chame à frente, pelo nome e pela função, cada oficial eleito.', 'posse'));
push(num('**Palavra breve.** Cada função é um chamado de Deus, discernido em oração, e não um posto de honra.', 'posse'));
push(...citacao('Quanto melhor conheçam a Cristo, mais fielmente O representarão no mundo. Devem escutar-Lhe a voz e estar atentos às Suas palavras.', 'T9 265.1'));
push(num('**Compromisso dos oficiais.** “Vocês aceitam, pela graça de Deus, servir fielmente nesta função, buscando discernir e fazer a vontade dEle, e não a própria?” Resposta: “Sim, com a ajuda de Deus.”', 'posse'));
push(num('**Compromisso da igreja.** “Igreja, vocês se comprometem a apoiar, em oração e cooperação, estes irmãos e irmãs?” Resposta: “Sim, com a ajuda de Deus.”', 'posse'));
push(num('**Oração de consagração.** Ore pelo nome de cada oficial, pedindo sabedoria, força e a presença do Espírito Santo.', 'posse'));
passo('6', 'Depois da posse');
push(item('**Apagar os dados do site.** Com tudo resolvido, o presidente apaga a reunião do servidor. O relatório fica guardado só no celular dele.'));
push(item('**Guardar o relatório.** O secretário da igreja registra os oficiais eleitos.'));
push(item('**Se um cargo ficar vago durante o mandato,** e não houver comissão permanente, a Comissão Diretiva indica alguém para o restante do mandato, e a igreja vota (Manual da Igreja, cap. 10). Vale a mesma oração antes e a mesma anuência.'));

/* ===================== 5. PAPEL ===================== */
parte('PARTE 7', 'Sem celular: tudo em papel', 'Para quando faltar internet, bateria ou celular. Os passos são os mesmos.');
push(p('Leve uma folha com a lista de quem pode ser proposto, papeizinhos do mesmo tamanho, canetas iguais e um envelope.'));
push(num('**Passos 1 a 5:** iguais. O presidente lê os textos deste livro.', 'papel'));
push(num('**Propostas:** em oração, cada um escreve, num papelzinho, os nomes que discerne, dobra e põe no envelope. O secretário lê em voz alta só os nomes, sem dizer quantas vezes cada um apareceu, e escreve a lista única numa folha.', 'papel'));

push(num('**Observações e afinar:** a conversa é igual. Depois de conversar sobre todos os nomes, cada um preenche a sua ficha de observações (uma folha com todos os nomes), dobra e entrega. O secretário e mais um membro passam as somas para o quadro do secretário, fazem a conta e, se a lista ainda for grande, mantêm mais ou menos a metade com as maiores notas, sem cortar empates. Os que ficam passam de novo pelas observações, com mais atenção, numa folha nova.', 'papel'));
push(num('**Oração:** igual.', 'papel'));
push(num('**Voto:** em oração, cada um escreve na cédula o nome que discerne ser a escolha de Deus (ou até tantos nomes quantas forem as vagas; ou “ainda não discerni”), dobra e entrega. O secretário e mais um membro contam juntos. Vale a mesma regra: mais da metade dos votos dados.', 'papel'));
push(num('**No fim:** os papeizinhos são destruídos ali mesmo. Fica só a lista do que foi discernido.', 'papel'));
push(new Paragraph({ heading: HeadingLevel.HEADING_3, pageBreakBefore: true, children: [new TextRun('Ficha de observações')], spacing: { after: 100 }, keepNext: true }));
push(p('Uma folha por membro da comissão, a cada rodada. Para cada nome, escreva os pontos de cada linha (veja a legenda) e some.'));
push(p('**Legenda.** Ligação com Deus que você percebe: excelente 70, muito bom 56, bom 42, precisa crescer um pouco 28, precisa crescer muito 14. O que Deus revelou para a função e o chamado que você discerne: 15, 12, 9, 6, 3. Se não conhece a pessoa o bastante, escreva “não conheço” e não some.', { run: { size: 20 } }));
push(new Paragraph({ children: [new TextRun({ text: 'Função: ______________________   Rodada: ____', size: 21 })], spacing: { before: 160, after: 100 } }));
tabela([['', '', '', '', ''], ['', '', '', '', ''], ['', '', '', '', ''], ['', '', '', '', ''], ['', '', '', '', ''], ['', '', '', '', ''], ['', '', '', '', ''], ['', '', '', '', '']],
  ['Nome', 'Ligação com Deus (70)', 'O que a função pede (15)', 'O chamado que discirno (15)', 'Soma'], [2586, 1700, 1700, 1700, 1100]);
push(new Paragraph({ heading: HeadingLevel.HEADING_3, pageBreakBefore: true, children: [new TextRun('Quadro do secretário')], spacing: { after: 100 }, keepNext: true }));
push(p('Um por função. Escreva as somas recebidas de cada nome. Com cinco somas ou mais, risque a maior e a menor e faça a média das outras; com menos de cinco, a média de todas. Se a maior e a menor ficam a mais de 30 pontos uma da outra, avise a comissão: conversar e orar mais antes de votar. Na lista pequena, se os dois primeiros ficam a 5 pontos ou menos e um deles já serve na função, leia o lembrete do passo 8. Se a lista ainda for grande, mantenha mais ou menos a metade com as maiores notas, sem cortar empates.'));
tabela([['', '', '', ''], ['', '', '', ''], ['', '', '', ''], ['', '', '', '']], ['Nome', 'Somas recebidas', 'Maior e menor', 'Nota da comissão'], [2200, 3586, 1500, 1500]);
sub('Cédula');
push(p('Recorte quantas precisar. Uma por pessoa, a cada voto.'));
for (let i = 0; i < 3; i++) {
  push(new Paragraph({ children: [new TextRun({ text: 'Função: ______________________________', size: 21 })], spacing: { before: 240, after: 60 }, border: { top: { style: BorderStyle.DASHED, size: 6, color: SALVIA, space: 12 } } }));
  push(new Paragraph({ children: [new TextRun({ text: 'Em minha consciência, discirno que a escolha de Deus é: ____________________', size: 21 })], spacing: { after: 60 } }));
  push(new Paragraph({ children: [new TextRun({ text: '(Se ainda não discerniu, escreva “ainda não discerni”.)', size: 18, color: SALVIA })], spacing: { after: 120 } }));
}


push(new Paragraph({ heading: HeadingLevel.HEADING_3, pageBreakBefore: true, children: [new TextRun('Folha de indicação da classe')], spacing: { after: 100 }, keepNext: true }));
push(p('O secretário prepara uma por classe, com os nomes dos membros batizados daquela classe, e imprime uma cópia para cada membro.'));
push(new Paragraph({ children: [new TextRun({ text: 'Classe: ______________________________', size: 21 })], spacing: { before: 200, after: 80 }, border: { top: { style: BorderStyle.DASHED, size: 6, color: SALVIA, space: 12 } } }));
push(new Paragraph({ children: [new TextRun({ text: 'Em oração, marque até dois nomes: as pessoas desta classe que você discerne que Deus está chamando para ajudar a formar a comissão de nomeações.', size: 20 })], spacing: { after: 100 } }));
for (let i = 0; i < 6; i++) push(new Paragraph({ children: [new TextRun({ text: '☐   ______________________________', size: 21 })], spacing: { after: 70 } }));
push(nota('Sem a lista impressa: entregue um papel em branco. Cada um escreve, em oração, até dois nomes de pessoas da própria classe.'));
push(new Paragraph({ children: [new TextRun({ text: 'Dobre e devolva ao professor.', size: 18, color: SALVIA })], spacing: { after: 240 } }));
sub('Ficha de objeção');
push(p('Preenchida pela comissão quando alguém traz uma razão séria, antes da segunda leitura. Fica com o presidente, em sigilo.'));
['Quem trouxe a observação: ______________________________', 'Função e nome em questão: ______________________________', 'Os fatos (não impressões): ______________________________', '______________________________________________________', 'Decisão da comissão, depois de orar:   ☐ mantém   ☐ muda a recomendação', 'Data: ____/____/______'].forEach(t => push(new Paragraph({ children: [new TextRun({ text: t, size: 21 })], spacing: { after: 110 } })));

/* ===================== 6. INSTALAÇÃO ===================== */
parte('PARTE 8', 'Uma vez só: instalar o site', 'Para quem vai cuidar do site do distrito. Uns quarenta minutos, num computador, uma única vez. Depois disso, todas as igrejas usam o mesmo endereço.');
push(p('Você vai precisar de três coisas: o arquivo **index.html** e o arquivo **regras_firestore.txt** (os dois vieram com este livro), sua conta Google e sua conta no GitHub.'));
push(p('Nenhum passo precisa de programação. Se algum botão estiver com outro nome, procure o mais parecido. Se travar, tire um print da tela e mande aqui no chat do Claude (modelo Opus), dizendo em que passo está.'));
const inst = [
  ['Criar o projeto no Firebase', 'No computador, abra **console.firebase.google.com** e entre com sua conta Google. Clique em **Criar um projeto** (ou Adicionar projeto). Nome: comissao-nomeacoes. Quando perguntar sobre o Google Analytics, desligue. Clique em Criar e espere.', 'O Firebase é o banco de dados gratuito do Google. É ele que faz os celulares conversarem.'],
  ['Registrar o site e guardar o código', 'Na página inicial do projeto, clique no ícone **</>** (Web). Apelido: site da comissão. Não marque a opção de Hosting. Clique em Registrar app. Vai aparecer um bloco que começa com **const firebaseConfig**. Copie esse bloco inteiro e cole no aplicativo Notas. Guarde.', 'Esse bloco é a “chave de endereço” do banco de dados. Você vai colar no celular no passo 8.'],
  ['Ligar a entrada sem conta', 'No menu da esquerda, abra **Criação** (Build) e depois **Authentication**. Clique em Vamos começar. Na aba Método de login, escolha **Anônimo**, ative e salve.', 'Cada celular ganha uma identidade invisível, sem e-mail e sem senha. Ninguém precisa criar conta.'],
  ['Criar o banco de dados', 'Em Criação (Build), abra **Firestore Database** e clique em Criar banco de dados. Se perguntar a edição, escolha Standard. Local: **southamerica-east1 (São Paulo)**. Escolha **iniciar no modo de produção** e crie.', 'São Paulo deixa tudo mais rápido aqui no Brasil. O modo de produção começa fechado; o próximo passo abre só o necessário.'],
  ['Colar as regras de segurança', 'Ainda no Firestore, abra a aba **Regras**. Apague tudo o que estiver lá. Abra o arquivo regras_firestore.txt, copie todo o conteúdo e cole no lugar. Clique em **Publicar**.', 'As regras garantem que só o presidente muda a reunião e que ninguém altera o voto de outro.'],
  ['Publicar o site no GitHub', 'Abra **github.com**, clique em **+** e depois **New repository**. Nome: comissao. Deixe como **Public** e crie. Na página do repositório, clique em **uploading an existing file**, arraste o arquivo index.html e clique em Commit changes. Depois vá em **Settings**, depois **Pages**. Em Branch, escolha **main** e a pasta **/(root)** e salve. Espere uns dois minutos.', 'O site em si não guarda nenhum dado; por isso pode ser público. Os dados ficam no Firebase, protegidos pelas regras.'],
  ['Autorizar o endereço do site', 'O endereço será **johngalvao7-lgtm.github.io/comissao**. No Firebase, abra Authentication, depois a aba **Configurações** (Settings), depois **Domínios autorizados**. Clique em Adicionar domínio e escreva: johngalvao7-lgtm.github.io', 'Assim o Firebase só aceita entradas vindas do seu site.'],
  ['Ligar o seu iPhone ou o seu Mac', 'No Safari do iPhone ou do Mac, abra o endereço do site. Toque em **Ligar este aparelho ao banco de dados**, cole o bloco que você guardou no passo 2 e toque em Ligar. Para ficar à mão: botão Compartilhar, depois Adicionar à Tela de Início.', 'Só o aparelho de quem conduz precisa disso. No Mac, a tela grande ajuda: o QR code fica fácil de ler, e o presidente acompanha tudo com folga. Deixe o Mac na tomada e com a tela sem apagar. Os membros entram pelo QR code, que já leva tudo junto.'],
  ['Testar com dois celulares', 'Toque em Conduzir uma reunião e crie uma reunião de teste, com três nomes inventados. Num segundo celular, leia o QR code e entre. Faça uma proposta, um voto e veja o resultado. No fim, apague a reunião (no relatório final).', 'Testar em casa evita surpresa no dia da comissão.']
];
inst.forEach(([t, a, q], i) => { passo(String(i + 1), t); push(rot('AGORA')); push(p(a, { keepNext: true })); push(rot('POR QUÊ')); push(p(q, { run: { color: SALVIA } })); });
sub('Para os presidentes das outras igrejas');
push(p('Eles não instalam nada. Mande para o celular de cada um o bloco que você guardou no passo 2, para colar no passo 8. Ou mande qualquer link de reunião: ao abrir, o celular já fica ligado ao banco de dados.'));
sub('Quanto custa');
push(p('Nada. O plano gratuito do Firebase permite 50 mil leituras e 20 mil gravações por dia. Uma reunião inteira usa algumas centenas.'));
sub('Quer só experimentar antes de instalar?');
push(p('Abra o arquivo index.html no navegador do computador e toque em **Só experimentar, neste aparelho**. Abra outras abas do mesmo navegador para fazer o papel dos membros. Nada sai do computador.'));

/* ===================== 7. TEXTOS COMPLETOS ===================== */
parte('PARTE 9', 'Os textos completos', 'Para estudar com calma, antes da reunião. Cada texto aparece uma vez. Na reunião, usamos só uma frase de alguns deles.');
push(nota('As referências seguem a forma abreviada usada nos escritos de Ellen G. White: T = Testemunhos para a Igreja (volume e página); TM = Testemunhos para Ministros; OE = Obreiros Evangélicos; LC = Liderança Cristã; ME2 = Mensagens Escolhidas, v. 2; CES e CES38 = Conselhos sobre a Escola Sabatina (duas edições); SC = Serviço Cristão; TS2 = Testemunhos Seletos, v. 2. Os textos vêm da compilação “Diretrizes de Deus nos Escritos de Ellen White para a Escolha de Oficiais Locais na IASD” e do estudo completo “Escolha de Oficiais e Estrutura Organizacional Adventista”, que continua sendo o material para aprofundar.'));
let grupo = '';
const CIENCIA = [
  ['Propostas em silêncio, antes de conversar (passo 6).', 'Grupos em que cada um pensa sozinho primeiro produzem mais ideias, e melhores, do que grupos que discutem em voz alta desde o início: na conversa aberta, quem fala acaba travando os outros.', 'Diehl, M.; Stroebe, W. (1987). Productivity loss in brainstorming groups. Journal of Personality and Social Psychology, 53(3), 497-509. Paulus, P. B.; Yang, H.-C. (2000). Idea generation in groups. Organizational Behavior and Human Decision Processes, 82(1), 76-87.'],
  ['Cada um conta o que só ele sabe (passo 7).', 'Grupos tendem a conversar sobre o que todos já sabem e a deixar de lado o que só um sabe. Pedir de propósito essas informações melhora a decisão.', 'Stasser, G.; Titus, W. (1985). Pooling of unshared information in group decision making. Journal of Personality and Social Psychology, 48(6), 1467-1478.'],
  ['As mesmas características, na mesma ordem, para cada nome, desde a lista grande (passo 7).', 'Avaliações estruturadas, com os mesmos critérios para todos, preveem bem melhor como a pessoa vai servir do que conversas livres.', 'Schmidt, F. L.; Hunter, J. E. (1998). The validity and utility of selection methods in personnel psychology. Psychological Bulletin, 124(2), 262-274.'],
  ['Cada um marca sozinho, e as marcações são somadas (passos 7 e 8).', 'Julgamentos independentes, depois combinados, erram menos. Quando as pessoas veem a opinião das outras antes de dar a sua, as respostas ficam parecidas e o resultado do grupo piora.', 'Lorenz, J.; Rauhut, H.; Schweitzer, F.; Helbing, D. (2011). How social influence can undermine the wisdom of crowd effect. PNAS, 108(22), 9020-9025. Kahneman, D.; Sibony, O.; Sunstein, C. R. (2021). Noise: A Flaw in Human Judgment. Little, Brown.'],
  ['Tirar a maior e a menor nota (passo 8).', 'A média sem os extremos protege o resultado de uma nota fora da curva, sem desprezar o que o grupo percebeu.', 'Wilcox, R. R. (2012). Introduction to Robust Estimation and Hypothesis Testing (3. ed.). Academic Press.'],
  ['Voto secreto (passo 9).', 'Quando a resposta é pública, as pessoas tendem a acompanhar a maioria mesmo discordando. O anonimato diminui essa pressão.', 'Deutsch, M.; Gerard, H. B. (1955). A study of normative and informational social influences upon individual judgment. Journal of Abnormal and Social Psychology, 51(3), 629-636.']
];
textos.forEach(q => {
  if (q.g !== grupo) { grupo = q.g; push(new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun(grupo)], spacing: { before: 480, after: 160 }, keepNext: true })); }
  push(new Paragraph({ children: [new TextRun({ text: q.titulo, bold: true, size: 21 })], spacing: { before: 160, after: 60 }, keepNext: true }));
  push(...citacao(q.texto, q.ref, q.nota));
});

push(new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun('O que a pesquisa confirma sobre o método')], spacing: { before: 480, after: 120 }, keepNext: true }));
push(p('A ciência aqui não escolhe ninguém. Ela só mostra por que estes jeitos de conversar, marcar e votar ajudam a comissão a ouvir melhor.', { run: { color: SALVIA } }));
CIENCIA.forEach(([t, d, r]) => { push(new Paragraph({ children: [new TextRun({ text: t, bold: true, size: 21 })], spacing: { before: 160, after: 60 }, keepNext: true })); push(p(d, { after: 40, keepNext: true })); push(nota(r)); });

/* ===================== 8. POR QUE ASSIM ===================== */
parte('PARTE 10', 'Por que assim', 'As decisões de escrita e de desenho, e para onde foi cada peça da primeira versão.');
sub('As decisões');
const dec = [
  ['As classes indicam para a organizadora.', 'É a ideia do pastor, mantida: todos participam (LC 59.2), cada um indica quem conhece de perto, e as classes, que costumam ser por idade, trazem gente de todas as idades. O que foi melhorado: cada um indica da própria classe; entra o mais indicado de cada classe e completa-se com os mais indicados; a contagem nunca é anunciada; e quem escolhe, no fim, é a igreja reunida, como pede o Manual.'],
  ['O jeito 2 do Manual como padrão.', 'Comissão Diretiva mais cinco a sete pessoas: o mesmo tamanho do jeito 1, com uma votação a menos. Se a igreja preferir o jeito 1, as classes indicam a organizadora inteira.'],
  ['Até dois nomes por folha.', 'O Manual limita a uma pessoa só a indicação falada. Na folha, dois nomes ajudam a mostrar quem a classe sente de verdade. Pode ser um, se preferir.'],
  ['O mesmo site para as duas comissões.', 'A organizadora usa os mesmos passos da comissão de nomeações, com o quadro de equilíbrio do Manual. Uma ferramenta a menos para aprender.'],
  ['Presidentes treinados onde o pastor não alcança.', 'Dez comissões em quatro semanas não cabem na agenda de um pastor. O Manual permite que a organizadora recomende outro presidente.'],
  ['Posse no primeiro sábado do mandato.', 'Os oficiais tomam posse quando começam a servir. Pode ser no último sábado do mandato anterior, se a igreja preferir.'],
  ['Um livro que é um roteiro.', 'A primeira versão tinha bases num volume e ferramentas em outro. Agora cada ferramenta e cada texto aparecem no passo em que são usados. Quem nunca conduziu uma comissão segue a ordem e chega ao fim.'],
  ['Cada membro no próprio celular.', 'Propostas e voto ficam secretos de verdade, e as propostas viram a lista sozinhas. O plano em papel continua no livro para quando faltar internet.'],
  ['Afinar sem maioria; maioria só no voto.', 'A lista grande diminui aos poucos pela nota da comissão, mantendo mais ou menos a metade a cada rodada. A maioria decide uma vez só, depois da oração.'],
  ['Maioria é mais da metade dos votos dados.', 'Brancos contam. Assim um nome só é discernido quando a maior parte da comissão sente o mesmo. Isso pode ser mudado para “mais da metade dos votos válidos”, se preferir.'],
  ['Uma pessoa por vez.', 'Para anciãos, diáconos e diaconisas, a comissão discerne uma pessoa, ora de novo e discerne a próxima. Isso mantém a oração antes de cada escolha.'],
  ['Alternância não elimina.', 'Fica quem anda mais perto de Deus, com chamado e habilidade, mesmo que já sirva. Só no empate em tudo, menos na experiência, vale dar a vez. O site mostra isso como lembrança na hora da oração, sem empurrar.'],
  ['Observações desde a lista grande.', 'Ideia do pastor, adotada: todos os nomes propostos passam pelas mesmas três características, rápido na lista grande e com atenção na pequena. A lista é afinada pela nota da comissão, e não por marcas soltas, para que ninguém saia por gosto pessoal. Isso também tirou um mecanismo inteiro: antes havia marcas para afinar e notas para observar; agora há só as notas.'],
  ['Perguntas em atitude de dependência de Deus.', 'Como nos Volumes I e II, nenhuma pergunta pede a opinião ou o voto de alguém: todas perguntam o que a pessoa percebe ou discerne ser a vontade de Deus. “Em sua consciência, quem você discerne ser a escolha de Deus?” no lugar de “em quem você vota?”; “ainda não discerni” no lugar de “em branco”. O voto continua sendo voto, como pede o Manual; muda a atitude de quem vota.'],
  ['Na lista impressa, o padrão; escrever à mão, a reserva.', 'Marcar nomes numa lista evita esquecimentos e grafias diferentes. Quando não der para preparar as listas, cada um escreve os nomes num papel. Isso aparece só como nota, para não virar o caminho normal.'],
  ['Quantas pessoas por função, definido antes.', 'O presidente diz, no passo 5, quantas pessoas a função pede. No voto, o site deixa tocar em até esse número de nomes, e só em um quando a função é de uma pessoa. Assim ninguém marca a mais por engano, e várias vagas podem ser discernidas de uma vez, cada nome com mais da metade dos votos.'],
  ['Tudo num sábado, como alternativa.', 'Ideia do pastor, adotada para distritos grandes: os mesmos passos, no mesmo dia, como nas assembleias. Fica como alternativa ao jeito de várias semanas, com três cuidados contra a pressa: preparo antes, listas prontas e hora para parar. A organizadora trabalha durante a lição da Escola Sabatina, e não durante o sermão, porque inclui o pastor e os anciãos, que costumam conduzir o culto.'],
  ['O livro com menos amarras de página.', 'A versão anterior mandava manter juntos muitos parágrafos seguidos. O Pages obedece a isso de um jeito diferente e deixava páginas com uma frase só. Agora só os títulos ficam presos ao texto que vem depois. Para imprimir, use o PDF que vai junto.'],
  ['A nota com peso voltou, como ajuda.', 'Cada um marca em silêncio as três características reveladas, com o peso já decidido antes (70%, 15% e 15%), e o site faz a conta. Para o número não virar a decisão, ele aparece só depois das observações, como quadro da comissão, e o voto vem depois da oração. No papel, os pontos já estão em cada quadradinho: basta somar.'],
  ['“Não conheço o bastante” vale para a pessoa inteira.', 'Antes havia “sem impressão” em cada linha, o que obrigava a refazer a conta dos pesos. Agora, quem não conhece a pessoa não marca nenhuma linha dela. Fica igual no site e no papel.'],
  ['O empate aparece sozinho.', 'Na lista pequena, quando os dois primeiros ficam a 5 pontos ou menos e um deles já serve, o site mostra o princípio da alternância. É o seu critério: só no mesmo nível em tudo vale dar a vez. Os 5 pontos podem mudar.'],
  ['Observações, com esse nome.', 'O passo segue as palavras do seu roteiro: função e características, propostas, observações, oração e voto.'],
  ['Samueis é uma imagem, não uma comissão.', 'Ela aparece só na abertura do livro, para explicar o sentido do processo.'],
  ['Sigilo por desenho.', 'O site não mostra quem propôs nem quem votou em quem. Anotações ficam só no celular de cada um. No fim, o presidente apaga tudo do servidor.']
];
dec.forEach(([a, b]) => push(new Paragraph({ children: [new TextRun({ text: a + ' ', bold: true }), new TextRun(b)], spacing: { after: 140, line: 312 } })));
sub('Para onde foi cada peça da primeira versão');
const mapa = [
  ['Volume I, fundamentos resumidos', 'substituídos pelos textos originais (Parte 9) e pelas frases das reuniões.'],
  ['Fase 0 e Ferramenta 1 (preparo e estudo da igreja)', 'Parte 3, passo 1.'],
  ['Fases 1 a 3 (organizadora e comissão de nomeações)', 'Parte 3, passos 2 a 7.'],
  ['Ferramenta 2 (ficha de delegados e checklist de representatividade)', 'site no modo organizadora e quadro de equilíbrio.'],
  ['Fase 4 (preparo espiritual da comissão)', 'Parte 5, passos 2 a 4.'],
  ['Fases 5 a 7 (listas grande, média e pequena)', 'Parte 5, passos 6 a 8, sem nome técnico.'],
  ['Ficha 6 e 6-B (pontuação e consolidação)', 'Parte 5, passos 7 e 8, com a conta automática no site; no papel, ficha de observações e quadro do secretário (Parte 7).'],
  ['Alerta de divergência (mais de 30 pontos)', 'aviso no quadro da comissão (passo 8).'],
  ['Corte por alternância', 'aviso de empate no quadro e lembrança na hora da oração.'],
  ['Ferramentas 3, 4 e 5 (abertura, propostas, apresentação)', 'Parte 5, passos 1 a 8.'],
  ['Fases 8 a 11 (anuência, leituras, objeções, voto)', 'Parte 6, passos 1 a 4.'],
  ['Ficha 8-B (objeção)', 'ficha de objeção, Parte 7.'],
  ['Cédulas', 'Parte 7.'],
  ['Fase 12 e roteiro de posse', 'Parte 6, passos 5 e 6.'],
  ['Cronograma', 'Parte 2 e o arquivo de calendário.'],
  ['Planilha Excel e as quatro ferramentas digitais', 'substituídas pelo site único.'],
  ['Esferas superiores (Associação e União)', 'ficam para uma próxima etapa.']
];
mapa.forEach(([a, b]) => push(new Paragraph({ children: [new TextRun({ text: a + ': ', bold: true }), new TextRun(b)], spacing: { after: 100, line: 300 } })));
sub('Duplicações resolvidas na compilação');
push(p('T9 264.2 e 265.1; T7 256.2; SC 46.6-46.7; os dois trechos sobre a Escola Sabatina e a mudança de oficiais; “Escolham-se os mais habilitados” (dentro de T6 85-86). OE 448.3 é o mesmo texto de T7 258.4, que ficou como fonte. Cada um aparece agora uma vez.'));
sub('Referências que ainda precisam ser conferidas');
push(p('Estes textos estão na compilação, mas sem o parágrafo exato. Ficaram marcados na Parte 9 e não são usados como citação na reunião, com exceção dos dois da Escola Sabatina, citados só pelo nome do livro:'));
['“Ao escolher oficiais, de tempos em tempos, assegurai-vos de que não vos dominam preferências pessoais”.',
 '“Colocai em cargos de confiança os que amam e temem a Deus”.',
 '“Sempre há segurança em ser manso, humilde e compassivo”.',
 '“A rede do evangelho...” e “Também cumpre tomar em consideração a família...” (T5 617-618).',
 '“Os dirigentes de igrejas devem em toda parte...” e “Para os pequenos grupos...” (T5 618-619).',
 '“Poder-se-á nomear uma pessoa...” (T5 619; provavelmente 619.1).',
 '“A frequente mudança de oficiais...” e “Não convém deixar a Escola Sabatina...” (Conselhos sobre a Escola Sabatina).',
 '“Mudança de obreiros” (presidente de associação).'].forEach(t => push(item(t)));
push(p('Os trechos de Ms 8, 1863 e Lt 97, 1892 são tradução livre do inglês. Se houver versão oficial em português, ela deve substituir esta.'));

/* ===================== 9. BOLSO ===================== */
parte('PARTE 11', 'Resumo de bolso');
['**Preparar a igreja:** 1 Samuel 16 e Atos 1. Em distritos grandes, do indicar das classes ao começo da comissão, tudo num sábado.',
 '**Escolher o jeito:** Comissão Diretiva mais cinco a sete; tamanho da comissão de nomeações.',
 '**Classes indicam:** até dois nomes da própria classe, em silêncio, envelope fechado.',
 '**Contar:** o mais indicado de cada classe, depois os mais indicados; equilíbrio; concordância.',
 '**Igreja vota a organizadora.** Ela discerne a comissão de nomeações no site.',
 '**Igreja vota a comissão e o quórum.**',
 '**Na comissão:** oração; combinados; cinco frases; e, para cada função: o que Deus pede, propostas em silêncio, observações de todos os nomes com as três características (70, 15 e 15), o quadro e o afinar pela nota até ficarem dois ou três, oração e voto secreto.',
 '**Voto:** até tantos nomes quantas forem as vagas; cada nome precisa de mais da metade dos votos dados; sem maioria, orar mais.',
 '**Anuência** antes de tudo.',
 '**1ª leitura** sem voto; uma semana para observações, pessoalmente.',
 '**2ª leitura** e voto da igreja.',
 '**Posse** no primeiro sábado do mandato. Depois, apagar os dados do site.'].forEach(t => push(p(t, { after: 110 })));
push(...citacao('Devemos apresentar a Deus cada caso, e, com oração fervorosa, pedir-Lhe que escolha por nós.', 'T9 264.1'));

/* ===================== DOCUMENTO ===================== */
const doc = new Document({
  creator: 'Pr. João Galvão', title: 'Discernindo a vontade de Deus',
  styles: {
    default: { document: { run: { font: FONTE, size: 22, color: TINTA } } },
    paragraphStyles: [
      { id: 'Heading1', name: 'Heading 1', basedOn: 'Normal', next: 'Normal', quickFormat: true, run: { size: 44, bold: true, font: FONTE, color: TINTA }, paragraph: { outlineLevel: 0 } },
      { id: 'Heading2', name: 'Heading 2', basedOn: 'Normal', next: 'Normal', quickFormat: true, run: { size: 29, bold: true, font: FONTE, color: TINTA }, paragraph: { outlineLevel: 1 } },
      { id: 'Heading3', name: 'Heading 3', basedOn: 'Normal', next: 'Normal', quickFormat: true, run: { size: 24, bold: true, font: FONTE, color: TINTA }, paragraph: { outlineLevel: 2 } }
    ]
  },
  numbering: {
    config: [
      { reference: 'pontos', levels: [{ level: 0, format: LevelFormat.BULLET, text: '•', alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 400, hanging: 260 } }, run: { color: OURO } } }] },
      ...['numeros', 'perguntas', 'depois', 'papel', 'posse'].map(r => ({ reference: r, levels: [{ level: 0, format: LevelFormat.DECIMAL, text: '%1.', alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 420, hanging: 320 } }, run: { color: OURO, bold: true } } }] }))
    ]
  },
  sections: [{
    properties: { page: { size: { width: 11906, height: 16838 }, margin: { top: 1418, bottom: 1418, left: 1560, right: 1560 } } },
    footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ children: [PageNumber.CURRENT], color: SALVIA, size: 18 })] })] }) },
    children: corpo
  }]
});
Packer.toBuffer(doc).then(b => { fs.writeFileSync(__dirname + '/Discernindo_a_vontade_de_Deus.docx', b); console.log('ok', b.length); });
